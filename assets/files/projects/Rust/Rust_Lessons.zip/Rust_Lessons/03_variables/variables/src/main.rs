fn main() {
    //  Immutablility
    //  If you take out the 'mut' from the line below. You will get errors.
    println!("Immutability test.\n");
    let mut x = 5;
    println!("The value of x is: {}", x);
    x = 6;
    println!("The value of x is: {}", x);
    println!();

    //  Shadowing
    //  When variables are reused and redeclared using the let keyword, we shadow it.
    println!("Shadowing test.\n");

    let x = 5;

    let x = x + 1;

    let x = x * 2;

    println!("The value of x is: {}", x);
    println!();

    //  Using shadowing we can mutate a variable's value and type by redeclaring the variable.
    //  This means that a whole new variable with the same name is created and it's variable and
    //  type defined when created again. The old variable is erased.

    //  When using mut, we can change the variable in place, which is faster because we do not need
    //  to create a whole new variable, but more restraining because we can not change the type
    //  unless we shadow it.

    //  Below we have the data types!

    //  Scalar types are integers, floating-point numbers, Booleans and characters

    //  INTEGERS
    let _small   : u8    = 100;                  //  This value can be at most 255.
    let _n_small : i8    = 100;                  //  This value can be at most 127, but has negative numbers too.
    let _medium  : u16   = 1_000;                //  This value can be at most 65,535.
    let _n_medium: i16   = 1_000;                //  This value can be at most 32,768, but has negative numbers too.
    let _normal  : u32   = 1_000_000;            //  This value can be at most 4,294,967,296.
    let _n_normal: i32   = 1_000_000;            //  This value can be at most 2,147,483,648, but has negatives.
    let _large   : u64   = 1_000_000_000_000;    //  This value can be at most 1.844674407e19.
    let _n_large : i64   = 1_000_000_000_000;    //  This value can be at most 9.223372037e18, but has negatives.
    let _huge    : u128  = 12;                   //  This value can be at most 3.402823669e38.
    let _n_huge  : i128  = 12;                   //  This value can be at most 1.701411835e38, but has negatives.

    let _something: usize = 12;                   //  This is either 32-bit or 64-bit.
    let _n_some   : isize = 12;                   //  It depends on the system architecture.

    //  FLOATING-POINT
    let _x = 2.0;    //  f64 by default
    let _y: f32 = 3.0;   //  f32

    //  _Opeartions for mathematics
    let _sum = 5 + 10;
    let _difference = 10 - 5;
    let _product = 34 * 2;
    let _quotient = 34 / 2;
    let _remainder = 12 % 5;

    //  Boolean
    let _t = true;
    let _f: bool = false;

    //  Character type
    let _c = 'z';
    let _z = 'Z';

    //  Compound types --> Rust has two primitive compound types: tuples and arrays.

    //  Tuples
    let tup: (i32, f64, u8) = (500, 6.4, 1);

    let (x,y,z) = tup;

    println!("The values of x, y and z are: {}, {}, {}", x, y, z);

    let some_val = tup.0;

    println!("The value of the tuple at 0 is: {}", some_val);

    let (n, _, m) = tup;
    println!("Values of n and m are: {}, {}", n, m);
    println!();

    //  Arrays
    //  How to define an array
    let a = [1,4,6,7,3,4,3];

    //  How to define the type of an array
    let b: [i32; 3] = [4,6,7];

    //  How to define an array with the same value in all of its indecies.
    let _c = [4; 5];  //  Defines an array of size 5 with number 4 in all slots.

    //  Indexing
    let _first = a[0];
    let _second = b[1];

    //  FUNCTIONS --> see below the main function for fn implementations
    another_function();

    println!("Giving the next number the number 32.");
    function_with_parameters(32);

    println!("Using the sum function giving it 22 and 26 as parameters!");
    let sum1 = sum(22, 26);
    println!("Final answer --> {}", sum1);

    //  STATEMENTS VS. EXPRESSIONS

    //  Statments always end with ; and they do not return enything
    //  Expressions always return something
    let expr_value = {
        let temp_val = 5;
        let other_val = 6;
        sum(temp_val, other_val)
    };
    //  expr_value should be 11
    println!("The final value of expr_value is {}", expr_value);


    //  FLOW CONTROL --> Conditionals
    //  For the choose function see bottom of the file.
    let mut choice = 5;
    choose(choice);
    choice = 15;
    choose(choice);

    //  FLOW CONTROL --> Loops --> While loops
    let mut i = 0;

    println!("Again using basic loop stmt!");
    loop
    {
        print!("{}   ", i);
        i += 1;
        if i == 10
        {
            break;
        }
    }
    println!();
    println!("Again but with while loop.");
    while i > 0
    {
        print!("{}   ", i);
        i -= 1;
    }
    println!();

    //  FLOW CONTROL --> loops --> For loops
    //  The for loop is usually used when looping through a collection like most other languages.

    let collection = [2,4,7,3,5,43,9,6,4];

    for elem in collection.iter()
    {
        println!("Current value is = {}", elem);
    }

}

//  Simple function
fn another_function()
{
    println!("This is the entrance of another_function.");
}

//  Simple function with parameters
fn function_with_parameters(para:i32)
{
    println!("Here is the number plus 5 --> {}", para + 5);
}

//  Simple funciton with parameters and return type
fn sum(x:i32, y:i32) -> i32
{
    x + y
}

//  Funciton used in conditional example
fn choose(choice:i32)
{
    if choice == 9
    {
        println!("Choice is exactly 9");
    }
    else if choice < 9
    {
        println!("Choice is less try higher!");
    }
    else
    {
        println!("Choice is too big try lower!");
    }
}
