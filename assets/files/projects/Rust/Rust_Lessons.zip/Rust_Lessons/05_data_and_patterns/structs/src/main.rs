struct User
{
    username: String,
    email: String,
    sign_in_count: u64,
    active: bool,
}

fn main() {

    let user1 = User
    {
        email: String::from("example@xyz.com"),
        username: String::from("example_guy/girl"),
        active: true,
        sign_in_count: 1,
    };

    print_user(&user1);

    let user2 = User
    {
        email: String::from("another@abc.com"),
        username: String::from("user23_anj"),
        ..user1
    };

    print_user(&user2);

    let user3 = build_user("someone@email.com".to_string(), "someone333".to_string());

    print_user(&user3);
}

fn build_user(email: String, username: String) -> User
{
    User
    {
        email,
        username,
        active: true,
        sign_in_count: 1,
    }
}

fn print_user(u: &User)
{
    println!("Email:            {}", u.email);
    println!("Username:         {}", u.username);
    println!("Active:           {}", u.active);
    println!("Times signed in:  {}", u.sign_in_count);
    println!();
}
