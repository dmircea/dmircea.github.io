//  This is like a class in c++ but it only holds data variables.
struct Rectangle
{
    width: u32,
    height: u32,
}

//  This is how you implment functions for the rectangle struct.
impl Rectangle
{
    //  Returns area of the triangle object.
    fn area(&self) -> u32
    {
        self.width * self.height
    }
}

fn main() {
    let rect1 = Rectangle{ width: 10, height: 20};

    println!("Area is {}", rect1.area());
    draw(&rect1);
}


//  Draws the rectangle on the terminal using stars
fn draw(rect: &Rectangle)
{
    for _h in 0..rect.height
    {
        for _w in 0..rect.width
        {
            print!("*");
        }
        println!();
    }
}
