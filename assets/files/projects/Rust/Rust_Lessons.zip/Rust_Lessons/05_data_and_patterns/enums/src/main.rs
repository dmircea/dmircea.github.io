//  The enum type can sometimes be used when we have value that can be
//  multiple values or nothing at all.
//  Think of the C++ optional type which can store a value of type T
//  or an std::nullopt that defines nothing.

//  Enum that are different than structs.
enum IpAddrKind
{
    V4(String),
    V6(String),
}

//  Another form of enums
enum Message
{
    Quit,   //  Has no data associated
    Move {x: i32, y:i32},   //  Includes anonymous struct inside it.
    Write(String),  //  Single string
    ChangeColor(i32, i32, i32), //  Just three i32 values.
}

//  You can also implement functions the same way you would in a struct.
impl Message
{
    fn call(&self)
    {
        println!("I am inside call!");
    }
}

fn main() {
    let four = IpAddrKind::V4;
    let six = IpAddrKind::V6;

    let home = IpAddrKind::V4(String::from("127.0.0.1"));
    let loopback = IpAddrKind::V6(String::from("::1"));

    let m = Message::Write(String::from("hello"));
    m.call();
}
