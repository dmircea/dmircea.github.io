
//  Utilization of match functon
//  Nice thing to know: patterns used in the match function can be
//      literals, variables, and even wildcards.
fn main() {
    let name = String::from("ram");

    //  Let's say we want to get the fifth value.
    //  There is no fifth letter in a 3 letter word.
    //  We can use the chars() string method to get back
    //  an iterator list. then nth() method to get the
    //  "nth" iterator so to speak.
    println!("char at postion 4 is: {}",
        match name.chars().nth(4)
        {
            //  If C is anything, print it
            Some(c) => c.to_string(),
            //  If nothing is found, print nothing.
            None => "No character found.".to_string(),
        }
    );

    //  Another example
    let integer = 5;

    match integer
    {
        1 => println!("one"),
        3 => println!("three"),
        5 => println!("five"),
        7 => println!("seven"),
        9 => println!("nine"),
        _ => (),    //  The underscore is often used as a place holder
        //  This can be a default action, or a throw away value
    }
}
