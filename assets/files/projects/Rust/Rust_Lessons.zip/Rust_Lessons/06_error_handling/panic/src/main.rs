//  Using file system from the std
use std::fs::File;

fn main() {
    // panic!("Crash and burn!");

    let v = vec![1,2,3];

    println!("Here is the first element of the vector: {}", v[0]);

    //  This line and will indirectly cause a panic because the program
    //  is trying to access the vector outside the bounds.
    //println!("Here is the 100th element of the vector: {}", v[99]);



    //  Recoverable errors are usually preffered when the error,
    //  can be handled with ease.
    //  Returns of functions often contains a result enum made of
    //  an OK with the value, or an Err with the error.

    //  the unwrap function at the end of this line does
    //  what the commented out lines below do, for the most part
    
    // let f = File::open("he.txt").unwrap();

    //  The expect function is like an unwrap but with a customized error message
    let f = File::open("he.txt").expect("We don't have the file yet!");


    // let foo = match f
    // {
    //     Ok(file) => file,
    //     Err(error) => {
    //         panic!("File was not found!");
    //     },
    // };
}
