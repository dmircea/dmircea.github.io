use std::io;
use std::cmp::Ordering;
use rand::Rng;

fn main() {
    println!("Guess the number!");

    let secret_number = rand::thread_rng().gen_range(1,101);
    let mut last_guess = 0;

    loop {
        println!("Please input your guess.");

        let mut guess = String::new();

        io::stdin().read_line(&mut guess).expect("Failed to read line");

        //  u32 is an unsigned 32-bit int, i32 is a 32-bit int, there is also u64 and i64
        let guess: u32 = match guess.trim().parse()
        {
            Ok(num) => num,
            Err(_) =>
            {
                println!("Please enter a number correctly!");
                continue;
            }
        };



        println!("You guessed: {}", guess);

        match guess.cmp(&secret_number)
        {
            Ordering::Less =>
            {
                println!("Too small!");
                if guess > last_guess
                {
                    println!("But getting closer!");
                }
                else if guess < last_guess
                {
                    println!("And getting farther.");
                }
                else
                {
                    println!("Did you just guess the same number?");
                }
            }
            Ordering::Greater =>
            {
                println!("Too big!");
                if guess < last_guess
                {
                    println!("But getting closer!");
                }
                else if guess > last_guess
                {
                    println!("And getting farther.");
                }
                else
                {
                    println!("Did you just guess the same number?");
                }
            }
            Ordering::Equal =>
            {
                println!("You win!");
                break;
            }
        }
        last_guess = guess;

    }   //  LOOP end
}
