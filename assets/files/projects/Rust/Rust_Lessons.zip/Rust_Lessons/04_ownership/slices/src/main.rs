fn main() {
    let s = String::from("Hello world!");

    //  The below & defines a borrowing from s.
    //  If it is not there there will be a compile time error because the compiler
    //  does not know the size of the string.
    let hello = &s[0..7];

    println!("hello contains {}", hello);
}
