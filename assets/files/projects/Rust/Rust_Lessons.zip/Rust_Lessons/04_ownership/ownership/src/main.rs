//  Testing and lesson program about ownership

fn main() {

    //  New scope created here
    {
        //  This variable will be unaccesible later on because it "goes out of scope"
        let _in_scope = 1;
    }
    let x = 1;
    let a = "Nice";

    if x == 1
    {
        let a = 45;
        println!("inside if stmt the variable a is {}", a);
    }

    println!("Outside if stmt the variable a is {}", a);


}
