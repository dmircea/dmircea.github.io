fn main() {

    let mut s = String::from("Placeholder");


    s.push_str(", something after placeholder!");

    println!("{}", s);


    let s1 = String::from("something!");
    // let s2 = s1;

    println!("{}", s1);
    // println!("{}", s2);


    take_ownership(s);
    take_ownership(s1); // This will take the entire value and give it to the function permanently
                        //  It is no longer possible to use that value anymore.
    // println!("{}", s1);  //  This line will cause issues

    //  Allow the variables to be used afterwards by using referneces
    let s3 = String::from("Third testing phase!");
    println!("{}", s3);

    dont_take_ownership(&s3);

    println!("{}", s3);

    //  Allow the varibales to be used and changed directly inside the function
    let mut s4 = String::from("Fourth testing");
    println!("{}", s4);

    dont_take_ownership_but_changable(&mut s4);

    println!("{}", s4);
}

fn take_ownership(val:String)
{
    println!("{}", val);
}

fn dont_take_ownership(val:&String)
{
    println!("{}", val);
}

fn dont_take_ownership_but_changable(val:&mut String)
{
    println!("{}", val);
    val.push_str(" and here is something extra!");
}
