

fn main()
{
    let refers_nothing = dangle();

    println!("{}", refers_nothing);
}

//  originally returned a dangling pointers but Rust compiler does not allows that.
fn dangle() -> String   //  &String originally
{
    let s = String::from("hello");

    s   //  &s; originally
}
