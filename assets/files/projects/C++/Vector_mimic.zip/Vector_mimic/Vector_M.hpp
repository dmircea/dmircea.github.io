#include <string>

template <typename T>
class Vector_M
{
private:
    //  Array pointer defined at construction time / deleted at destruction time.
    T* m_array; //  Default is an array of one item.
    //  Size of the array used on demand.
    int m_size;  //  Default is one.
    //  Growth multiplier, used when the number of items becomes above the current
    //  maximum.
    short m_growth; //  Default if multiplier 2.
    //  Used to keep track of maximum number of elements.
    int m_max_size;  //  Deafult is one but grows based on grows multiplier.

    void grow();

public:
    //  ------------------  Constructors and Destructors ------------------//
    Vector_M();
    Vector_M(int max_size);
    Vector_M(int max_size, short growth);
    ~Vector_M();

    //  TODO --> Copy constructor
    //  TODO --> Array constructor

    //  ------------------  Setters and Getters ---------------------------//

    int size() const;
    int max() const;

    T at(int index) const;


    //  ------------------  Funcionalities  -------------------------------//
    void push_back(T val);
    //  TODO --> to_string()
    //  TODO --> print() --> May not implement this
    //  TODO --> << overload for stream functonalities.

};

//  -------------------------   IMPLEMENTATIONS ---------------------------//

#include <iostream>     //  Temporary library for debugging

template <typename T>
Vector_M<T>::Vector_M()
{
    std::cout << "Default contructor." << std::endl;
    m_max_size = 1;
    m_size = 0;
    m_growth = 2;
    m_array = new T[m_max_size];
}

template <typename T>
Vector_M<T>::Vector_M(int max_size)
{
    std::cout << "Custom <max_size> contructor." << std::endl;
    m_max_size = max_size;
    m_size = 0;
    m_growth = 2;
    m_array = new T[m_max_size];
}

template <typename T>
Vector_M<T>::Vector_M(int max_size, short growth)
{
    std::cout << "Custom <max_size, growth> contructor." << std::endl;
    m_max_size = max_size;
    m_size = 0;
    m_growth = growth;
    m_array = new T[m_max_size];
}

template <typename T>
Vector_M<T>::~Vector_M()
{
    std::cout << "Default destructor of size " << m_max_size << std::endl;
    //std::cout << m_array[0];
    delete []m_array;
}

//  ------------------  Setters and Getters ---------------------------//
template <typename T>
int Vector_M<T>::size() const
{
    return m_size;
}

template <typename T>
int Vector_M<T>::max() const
{
    return m_max_size;
}

//  At function. Is constant function.
template <typename T>
T Vector_M<T>::at(int index) const
{
    if(index < 0)
    {
        throw std::out_of_range("Index was negative.");
    }
    else if (index >= m_max_size)
    {
        throw std::out_of_range("Index was above maximum value.");
    }
    return m_array[index];
}

template <typename T>
void Vector_M<T>::push_back(T val)
{
    //  Three statements.
    //  1. First increase size by one.
    //  2. If size ends up bigger than max, then growth happens
    //  3. Else, just put in val at size - 1 in the array;
    m_size++;
    if(m_size > m_max_size)
    {
        Vector_M::grow();
    }

    m_array[m_size - 1] = val;

}

template <typename T>
void Vector_M<T>::grow()
{
    int new_max_size = m_max_size * m_growth;
    T * new_array = new T[new_max_size];

    for(int i = 0; i < m_max_size; ++i)
    {
        new_array[i] = m_array[i];
    }

    delete[] m_array;
    m_array = new_array;

    m_max_size = new_max_size;
}
