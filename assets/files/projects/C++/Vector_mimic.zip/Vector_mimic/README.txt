This file will go over the following.

1.  The creation of this program.
2.  The purpose of this program
3.  The reason
4.  Future updates


1.  This program has been created by Mircea Dumitrache.

It was created with-in the timespan of approximately one week.



2.  The purpose of this program was to re-create the vector
data structure from the C++ STL. It is not intended to be
fully functional or a complete or identical copy, only an
imitation with possibly different future functionality.




3.  Primarily, I was intrigued by how the vector class works
behind the scenes and decided to attempt implementing an
imitation using my own process of thought on how it worked.





4.  Current future updates can be seen as a comment block in
main.cpp.
The comment block is copied here for convenience:

    INTRO
    This program was created by Mircea Dumitrache, student assistant at CSUF.

    PURPOSE
    The purpose of this program is to mimic the functionalities of the
    vector data type found in the STL.

    REASON
    I was originally interested in how the vector class worked behind the
    scenes. After some attempts to explain it using pure C++ code, I decided
    to attempt its construction using my own thought process.

    DEPENDENCIES
    This program depends on the string library, and may depend on the
    stream library. (The to_string function and operator<< overload function)

    FUTURE UPDATES
    The todo portion throughout the code and the test cases are the future
    updates. This includes:
        - Copy constructor
        - Array constructor
        - to_string() function
        - print() --> This may not be implemented, due to the addition of iostream
                      dependency
        - operator<< overloaded function for stream functionalities.
        - operator[] overloaded function for accessing and mutating using indices.
        - Change in functionality using push_front()
            -- instead of shifting all values forward by one, keep track of a current,
                front_start variable
            -- when vector is grown due to a push_front(), change front_start
                variable to somewhere near a third of the entire array, copy
                values from there, then add in the value to before front_start
            -- decrement front_start
    Timers against an actual vector from the STL.
