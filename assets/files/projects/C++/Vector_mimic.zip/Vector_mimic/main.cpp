#include "Vector_M.hpp"
#include<iostream>

/*
    INTRO
    This program was created by Mircea Dumitrache, student assistant at CSUF.

    PURPOSE
    The purpose of this program is to mimic the functionalities of the
    vector data type found in the STL.

    REASON
    I was originally interested in how the vector class worked behind the
    scenes. After some attempts to explain it using pure C++ code, I decided
    to attempt its construction using my own thought process.

    DEPENDENCIES
    This program depends on the string library, and may depend on the
    stream library. (The to_string function and operator<< overload function)

    FUTURE UPDATES
    The todo portion throughout the code and the test cases are the future
    updates.
    Timers against an actual vectore from the STL.
*/

int main()
{
    std::cout << "Test begin!" << std::endl;
    Vector_M<int> test_one;
    std::cout << "test_one created successfully!" << std::endl;

    std::cout << "gettters test!\n";

    std::cout << "Current size of test one is " << test_one.size() << '\n';
    std::cout << "Current maximum of test one is " << test_one.max() << "\n\n";

    std::cout << "Pushing back testing\n";

    for (int i = 5; i < 50; i += 5)
    {
        std::cout << "Pushing back a " << i << '\n';
        test_one.push_back(i);

        std::cout << "Current size of test one is " << test_one.size() << '\n';
        std::cout << "Current maximum of test one is " << test_one.max() << "\n\n";
    }

    //  Testing for at.


    //  Testing for print and to_string


    //  Testing with a stream operator overload


    //  Testing for constructor overload with array


    //  Testing for copy constructor


    std::cout << "Test end!" << std::endl;
    return 0;
}
