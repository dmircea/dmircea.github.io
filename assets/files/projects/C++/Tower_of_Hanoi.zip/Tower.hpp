#pragma once

#include "Disk.hpp"
#include "Utilities.hpp"

#include <iostream>

class Tower
{
  private:
    Disk holding[SIZE_OF_TOWER];
    bool starting_tower;

  public:
    Tower()
    {
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            holding[i].size = 0;
        }
        starting_tower = false;
    }

    void empty_out()
    {
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            holding[i].size = 0;
        }
    }

    void reset()
    {
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            holding[i].size = i + 1;
        }
    }

    //  Set the tower as the starting tower.
    void set_starting() { starting_tower = true; }

    //  Check if the tower is a starting tower.
    bool is_starting_tower() { return starting_tower; }

    //  This function will return the size of the top disk. If no disks are
    //  found the size returned will be 0.
    int size_of_top() const
    {
        int answer = 0;
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            if (holding[i].size > answer)
            {
                answer = holding[i].size;
                break;
            }
        }
        return answer;
    }

    //  This function will set the size of the top disk to 0, and returns true.
    //  It will return false if there are no disks.
    bool pop_top()
    {
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            if (holding[i].size != 0)
            {
                holding[i].size = 0;
                return true;
            }
        }
        return false;
    }

    //  Add a disk at the top of the tower
    //  This function does not worry about the tower being full. Assumed to be
    //  taken care of before the function is called.
    void add_top(int size)
    {
        if (is_empty())
        {
            holding[SIZE_OF_TOWER - 1].size = size;
        }
        else
        {
            for (int i = 1; i < SIZE_OF_TOWER; ++i)
            {
                if (holding[i].size != 0)
                {
                    holding[i - 1].size = size;
                    return;
                }
            }
        }
    }

    //  Check the top position. if the size if something other than 0, than the
    //  tower is full.
    bool is_full() { return holding[0].size != 0; }

    //  Check the last disk of the tower, if the size is 0 than it is empty
    //  (true)
    bool is_empty() { return holding[SIZE_OF_TOWER - 1].size == 0; }

    //  Attempts to move the top disk to the other tower given as a parameter.
    //  There are multiple return types given to this function:
    //  0 --> movement was successful.
    //  1 --> tower whose disk is supposed to be moved has no disks.
    //  2 --> other tower is full.
    //  3 --> disk to be moved is larger in size than top disk of other tower.
    int move_top_to(Tower &other)
    {
        //  TODO -- take the size of the top holding using the size_of_top
        //  function And try moving it to the other tower. If successful return
        //  true, otherwise false;
        int moveable_disk_size = size_of_top();
        if (moveable_disk_size == 0)
        {
            return 1;
        }
        if (other.is_full())
        {
            return 2;
        }
        if (moveable_disk_size > other.size_of_top() && !other.is_empty())
        {
            return 3;
        }

        other.add_top(moveable_disk_size);
        pop_top();

        return 0;
    }

    //  This function is an interface between the driver and disks through the
    //  tower. Only used for printing horizontally
    void print_disk_at(int index)
    {
        holding[index].print(SIZE_OF_TOWER * 2 + 1);
    }

    void print() const
    {
        //  Resize the print size in something printable in text.
        int largest = SIZE_OF_TOWER * 2 + 1;

        //  Set up the top of the tower, where there is no disk
        for (int i = 0; i < largest - 1; ++i)
        {
            if (i == largest / 2)
            {
                std::cout << 'X';
            }
            else
            {
                std::cout << ' ';
            }
        }
        std::cout << std::endl;

        //  Print the disks one by one by using their own specialized function.
        for (int i = 0; i < SIZE_OF_TOWER; ++i)
        {
            holding[i].print(largest);
            std::cout << std::endl;
        }

        //  Print the bottom board of the game.
        for (int i = 0; i < largest; ++i)
        {
            std::cout << '=';
        }
        std::cout << std::endl;
    }
};
