Project Creator: Mircea Dumitrache

This program is a representation of the tower of hanoi game made
using the C++ programming language. It prints out the towers
horizontally and asks the user for input.

The input should be two numbers separated by a space. The first number
is the tower from which you take a disk, and the second number is the
number where that disk should be placed.
Example: 1 2
Take a disk form tower 1 and place it on tower 2.

The rules of the game are:
1. You can't take a disk from an empty tower.
2. You can't place a bigger disk on top of a smaller disk.
3. You can only take one disk at a time.
4. You can only take the topmost disk form a tower.
