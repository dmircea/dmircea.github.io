#include "Tower.hpp"

void print_vertical(Tower all_towers[]);
void print_horizontal(Tower all_towers[]);
void print_towers(Tower all_towers[], char type);

void get_user_input(int &from, int &to);
bool check_win(Tower all_towers[]);

/*
    MAIN FUNCTION
*/
int main()
{
    Tower all_towers[NUMBER_OF_TOWERS];
    bool running = true;
    int from_which_tower = 1, to_which_tower = 0;

    all_towers[0].reset();
    all_towers[1].empty_out();
    all_towers[2].empty_out();

    all_towers[0].set_starting();

    while (running)
    {
        print_towers(all_towers, 'H');
        get_user_input(from_which_tower, to_which_tower);
        int return_code = all_towers[from_which_tower].move_top_to(
            all_towers[to_which_tower]);

        switch (return_code)
        {
        case 0:
            std::cout << "The disk was moved." << std::endl;
            break;
        case 1:
            std::cout
                << "The tower you chose has no disks. Please choose another."
                << std::endl;
            break;
        case 2:
            std::cout << "The tower you are moving the disk to is already full."
                      << std::endl;
            break;
        case 3:
            std::cout << "You cannot move a larger disk atop a smaller one."
                      << std::endl;
            break;
        }

        if (check_win(all_towers))
        {
            running = false;
            print_towers(all_towers, 'H');
            std::cout << "Congratulations you won!!" << std::endl;
        }

        from_which_tower = 0;
        to_which_tower = 0;
    }

    return 0;
}

/*
    UTILITY FUNCTIONS
*/
void print_vertical(Tower all_towers[])
{
    for (int i = 0; i < NUMBER_OF_TOWERS; ++i)
    {
        all_towers[i].print();
        std::cout << std::endl;
    }
}

void print_horizontal(Tower all_towers[])
{
    //  Print the towers all horizontally.
    for(int i = 0; i < SIZE_OF_TOWER; ++i)
    {
        for(int j = 0; j < NUMBER_OF_TOWERS; ++j)
        {
            all_towers[j].print_disk_at(i);
            std::cout << "\t\t";
        }
        std::cout << std::endl;
    }
}

void print_towers(Tower all_towers[], char type = 'V')
{
    if(type == 'V')
    {
        print_vertical(all_towers);
    }
    else
    {
        print_horizontal(all_towers);
    }
}

void get_user_input(int &from, int &to)
{
    while (((from < 1 || from > NUMBER_OF_TOWERS) ||
               (to < 1 || to > NUMBER_OF_TOWERS)) ||
           from == to)
    {
        std::cout << "Please choose which tower to take a disk from and on "
                     "which tower to place it (example input: 1 2): ";
        std::cin >> from >> to;

        // Incorrect input is checked and cleaned here.
        if (std::cin.fail())
        {
            std::cout << "Invalid input. Please try again." << std::endl;
            std::cin.clear();
            std::cin.ignore(5000, '\n');
            continue;
        }

        // If input is good, then check bounds.
        if (((from < 1 || from > NUMBER_OF_TOWERS) ||
            (to < 1 || to > NUMBER_OF_TOWERS)))
        {
            std::cout << "The towers must be numbers between 1 and "
                      << NUMBER_OF_TOWERS
                      << " in order to be considered correct." << std::endl;
        }
        else if (from == to)
        {
            std::cout << "You must choose different towers." << std::endl;
        }
    }

    from--;
    to--;
}

bool check_win(Tower all_towers[])
{
    for (int i = 0; i < NUMBER_OF_TOWERS; ++i)
    {
        if (all_towers[i].is_full() && !all_towers[i].is_starting_tower())
        {
            return true;
        }
    }
    return false;
}
