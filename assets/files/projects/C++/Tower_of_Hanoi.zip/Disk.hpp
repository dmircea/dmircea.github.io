#pragma once
#include <iostream>

//  If size is 0 than there is no disk, if size is positive than it has a disk
//  of that size

struct Disk
{
    //    The size of the disk and a constructor that sets the size.
    int size;
    Disk(int s = 0) : size(s) {}

    //    Speciallized pring function for printing a single disk to the screen
    //    The output is dependent on the size.
    //    The printed disk is twice the size plus one (in order to appropriately
    //    show the disk as if it was impaled on the tower handle.
    void print(int largest_size) const
    {
        int current_disk_size = size * 2 + 1;
        largest_size -= current_disk_size;
        for (int i = 0; i < largest_size + 1; ++i)
        {
            if (i == largest_size / 2)
            {
                for (int j = 0; j < current_disk_size; ++j)
                {
                    std::cout << 'X';
                }
            }
            else
            {
                std::cout << ' ';
            }
        }
        std::cout << "         " << size;
    }
};
