#pragma once

const int NUMBER_OF_TOWERS = 3;
const int SIZE_OF_TOWER = 7;
