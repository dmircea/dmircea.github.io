# project-3-starter
Project 3: raytracer

Group member:

Mircea Dumitrache --> dmircea@csu.fullerton.edu
