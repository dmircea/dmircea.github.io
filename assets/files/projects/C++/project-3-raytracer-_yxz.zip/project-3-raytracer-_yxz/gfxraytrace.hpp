///////////////////////////////////////////////////////////////////////////////
// gfxraytrace.hpp
//
// Basic ray tracer.
//
// This header includes the following classes, which are interrelated:
//
// - scene represents the complete raytracing process, and
//   composes the following classes, each of which is responsible for
//   a smaller part of raytracing:
//
//       - camera defines the viewer's location and orientation
//
//       - viewport defines the dimensions of the view window in both
//         world coordinates and sceen coordinates
//
//       - abstract_projection is an abstract class for a projection,
//         which can generate view rays
//
//           - orthographic_projection is an abstract_projection that
//             performs orthographic projection, with parallel view
//             rays
//
//           - perspective_projection is an abstract_projection that
//             performs perspective-correct projection, where all view
//             rays originate from the camera location
//
//       - abstract_shader is an abstract class for a shader, which
//         computes the color of a pixel based on a ray-object
//         itersection
//
//           - flat shader just passes object color through and does
//             not take lighting into account
//
//           - blinn_phong_shader uses the Blinn-Phong illumination
//             model to combine ambient light, diffuse light, and
//             specular highlights
//
// - view_ray is a viewing ray, with an origin and direction
//
// - abstract_scene_object is an abstract geometric scene object
//
//       - scene_sphere is a 3D sphere
//
//       - scene_triangle is a 3D triangle
//
//       - scene_mesh is a collection of scene_triangle objects
//
// - point_light is a light located at a specific location
//
// - intersection represents an intersection between a view ray and a
//   scene object
//
// - scene represents a scene that may be rendered, including lights,
//   scene objects, and a background color
//
// This file builds upon gfxnumeric.hpp and gfxalgebra.hpp, so you may want to
// familiarize yourself with those headers before diving into this one.
//
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <algorithm>
#include <memory>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "gfxalgebra.hpp"
#include "gfximage.hpp"
#include "rayson.hpp"

namespace gfx {

// Forward declarations of new class types, in alphabetical order.

class abstract_projection;
class abstract_scene_object;
class abstract_shader;
class blinn_phong_shader;
class camera;
class flat_shader;
class intersection;
class orthographic_projection;
class perspective_projection;
class point_light;
class raytracer;
class scene;
class scene_read_exception;
class scene_mesh;
class scene_sphere;
class scene_triangle;
class view_ray;
class viewport;

// Class declarations, in the order that classes are introduced in
// the comment above.

// A scene represents all the geometric information necessary to
// render an image. That includes:
//
// - a background color, used to fill a pixel whose view ray does
//   not intersect any scene object;
//
// - a vector of point lights; and
//
// - a vector of scene objects.
//
// Ordinarily you need at least one light, and many scene objects,
// to make an interesting image. However this is not enforced with
// assertions.
class scene {
public:
  using light_storage_type = std::vector<std::unique_ptr<point_light>>;
  using object_storage_type = std::vector<std::unique_ptr<abstract_scene_object>>;

private:
  std::unique_ptr<camera> camera_;
  std::unique_ptr<viewport> viewport_;
  std::unique_ptr<abstract_projection> projection_;
  std::unique_ptr<abstract_shader> shader_;
  hdr_rgb background_;
  light_storage_type lights_;
  object_storage_type objects_;

public:

  scene(scene&&) noexcept = default;

  scene() noexcept
  : background_(BLACK) {
    assert(!complete());
  }

  // Constructor.
  scene(std::unique_ptr<camera> camera,
        std::unique_ptr<viewport> viewport,
        std::unique_ptr<abstract_projection> projection,
        std::unique_ptr<abstract_shader> shader,
        const hdr_rgb& background) noexcept
  : camera_(std::move(camera)),
    viewport_(std::move(viewport)),
    projection_(std::move(projection)),
    shader_(std::move(shader)),
    background_(background) {

    assert(camera_);
    assert(viewport_);
    assert(projection_);
    assert(shader_);

    assert(complete());
  }

  constexpr bool complete() const noexcept {
    return (camera_ && viewport_ && projection_ && shader_);
  }

  // Accessors.
  const camera& camera() const noexcept {
    assert(camera_);
    return *camera_;
  }
  const viewport& viewport() const noexcept {
    assert(viewport_);
    return *viewport_;
  }
  const abstract_projection& projection() const noexcept {
    assert(projection_);
    return *projection_;
  }
  const abstract_shader& shader() const noexcept {
    assert(shader_);
    return *shader_;
  }
  constexpr const hdr_rgb& background() const noexcept {
    return background_;
  }
  constexpr const light_storage_type& lights() const noexcept {
    return lights_;
  }
  constexpr const object_storage_type& objects() const noexcept {
    return objects_;
  }

  // Mutators.
  void camera(std::unique_ptr<gfx::camera> camera) noexcept {
    camera_ = std::move(camera);
  }
  void viewport(std::unique_ptr<gfx::viewport> viewport) noexcept {
    viewport_ = std::move(viewport);
  }
  void projection(std::unique_ptr<abstract_projection> projection) noexcept {
    projection_ = std::move(projection);
  }
  void shader(std::unique_ptr<abstract_shader> shader) noexcept {
    shader_ = std::move(shader);
  }
  void background(const hdr_rgb& background) noexcept {
    background_ = background;
  }

  // Adding lights and objects.
  void add_light(std::unique_ptr<point_light> light) noexcept {
    lights_.emplace_back(std::move(light));
  }
  void add_object(std::unique_ptr<abstract_scene_object> object) noexcept {
    objects_.emplace_back(std::move(object));
  }

  // Trace a ray and find the closest intersecting scene object.
  //
  // If no such intersection exists, return an empty optional.
  //
  // If there is an intersection within that t range, return an optional that
  // contains that intersection object.
  std::optional<intersection> intersect(const view_ray& ray) const noexcept;

  // Render the given scene and return the resulting image.
  hdr_image render() const noexcept;

  // Load a scene from a JSON file; throws scene_read_exception on error.
  static scene read_json(const std::string& path) noexcept(false);
};

// An error encountered while trying to read and parse a scene file.
class scene_read_exception {
private:
  std::string path_;
  std::string message_;

public:
  scene_read_exception(const std::string& path,
                       const std::string& message) noexcept
  : path_(path), message_(message) { }

  const std::string& path() const noexcept { return path_; }
  const std::string& message() const noexcept { return message_; }
};

// The location and orientation of the camera. This is defined by a
// 3D point for the eye location; and a basis defined by three 3D
// normalized vectors.
class camera {
private:
  vector3<double> eye_, u_, v_, w_;

public:

  // Constructor that provides the eye location and three basis
  // vectors directly. u, v, and w must each be normalized (magnitude
  // 1.0).
  constexpr camera(const vector3<double>& eye,
                   const vector3<double>& u,
                   const vector3<double>& v,
                   const vector3<double>& w) noexcept
  : eye_(eye), u_(u), v_(v), w_(w) {

    assert(approx_equal(u.magnitude(), 1.0, .01));
    assert(approx_equal(v.magnitude(), 1.0, .01));
    assert(approx_equal(w.magnitude(), 1.0, .01));
  }

  // Constructor that computes the basis in terms of a given
  // view-direction and up vector.
  constexpr camera(const vector3<double>& eye,
                   const vector3<double>& view_direction,
                   const vector3<double>& up) noexcept;

  // Accessors and mutators.
  constexpr const vector3<double>& eye() const noexcept {
    return eye_;
  }
  constexpr const vector3<double>& u() const noexcept {
    return u_;
  }
  constexpr const vector3<double>& v() const noexcept {
    return v_;
  }
  constexpr const vector3<double>& w() const noexcept {
    return w_;
  }
};

// A viewport defines the boundary of the viewing window. It stores
// the width and height of the image, in screen coordinates; and the
// left, right, top, and bottom of the view window in world
// coordinates.
class viewport {
private:
  size_t x_resolution_, y_resolution_;
  double left_, top_, right_, bottom_;

public:

  // Constructor. The following inequalities must hold:
  //
  // x_resolution, y_resolution > 0
  // left < 0 < right
  // bottom < 0 < top
  //
  constexpr viewport(size_t x_resolution,
                     size_t y_resolution,
                     double left,
                     double top,
                     double right,
                     double bottom) noexcept
    : x_resolution_(x_resolution),
      y_resolution_(y_resolution),
      left_(left),
      top_(top),
      right_(right),
      bottom_(bottom) {
    assert(x_resolution > 0);
    assert(y_resolution > 0);
    assert(left < right);
    assert(bottom < top);
    assert(left < 0.0);
    assert(right > 0.0);
    assert(top > 0.0);
    assert(bottom < 0.0);
  }

  // Accessors.
  constexpr size_t x_resolution() const noexcept {
    return x_resolution_;
  }
  constexpr size_t y_resolution() const noexcept {
    return y_resolution_;
  }
  constexpr double left() const noexcept {
    return left_;
  }
  constexpr double right() const noexcept {
    return right_;
  }
  constexpr double top() const noexcept {
    return top_;
  }
  constexpr double bottom() const noexcept {
    return bottom_;
  }

  // Map an (x, y) screen coordinate to a (u, v) coordinate in
  // [0, 1]^2. Return a 2D vector x, with u in x[0] and v in x[1];
  vector2<double> uv(size_t x, size_t y) const noexcept;
};

// Abstract class defining a projection algorithm.
class abstract_projection {
public:

  // Given a camera and (u, v) coordinate within the viewport,
  // create and return the corresponding viewing ray. (u, v) are
  // expected to come from the camera::uv function.
  virtual view_ray compute_view_ray(const camera& c,
			                              double u,
			                              double v) const noexcept = 0;

  virtual ~abstract_projection() noexcept = default;
};

// Orthographic implementation of abstract_projection.
class orthographic_projection : public abstract_projection {
public:

  constexpr orthographic_projection() noexcept = default;

  virtual view_ray compute_view_ray(const camera& c,
			                              double u,
			                              double v) const noexcept;
};

// Perspective implementation of abstract_projection.
class perspective_projection : public abstract_projection {
private:
  double focal_length_;

public:

  // The perspective projection algorithm needs to know the
  // focal_length of the camera, which is the distance between the
  // eye and the view plane, and must be positive.
  constexpr perspective_projection(double focal_length) noexcept
  : focal_length_(focal_length) {
    assert(focal_length > 0.0);
  }

  // Accessor.
  constexpr double focal_length() const noexcept {
    return focal_length_;
  }

  virtual view_ray compute_view_ray(const camera& c,
			                              double u,
			                              double v) const noexcept;
};

// Abstract class defining a shading algorithm.
class abstract_shader {
public:

  // Given a scene, camera, and particular ray-object intersection,
  // compute the color of the pixel corresponding to the view
  // ray. The pixel's color is returned.
  virtual hdr_rgb shade(const scene& scene,
			                  const camera& camera,
		                    const intersection& xsect) const noexcept = 0;

  virtual ~abstract_shader() noexcept = default;
};

// Flat-shader implementation of abstract_shader.
class flat_shader : public abstract_shader {
public:

  virtual hdr_rgb shade(const scene& scene,
		                    const camera& camera,
		                    const intersection& xsect) const noexcept;
};

// Blin-Phong implementation of abstract_shader.
class blinn_phong_shader : public abstract_shader {
private:
  double ambient_coefficient_;
  hdr_rgb ambient_color_;
  double diffuse_coefficient_, specular_coefficient_;

public:

  // The Blinn-Phong model depends on the following parameters:
  //
  // ambient_coefficient is the multiplier for ambient light, which
  // must be non-negative. When zero there will be no ambient light.
  //
  // ambient_color is the color of ambient light; usually white in
  // daylight.
  //
  // diffuse_coefficient is the multiplier for diffuse light (object
  // color), which must be non-negative. When zero there is no
  // diffuse light, so only ambient and specular light would be
  // visible.
  //
  // specular_coefficient is the multiplier for specular light
  // (speckles/gloss/glare), which must be non-negative. When zero
  // there are no specular highlights so all objects appear matte.
  //
  blinn_phong_shader(double ambient_coefficient,
	                   const hdr_rgb& ambient_color,
	                   double diffuse_coefficient,
	                   double specular_coefficient)
  : ambient_coefficient_(ambient_coefficient),
    ambient_color_(ambient_color),
    diffuse_coefficient_(diffuse_coefficient),
    specular_coefficient_(specular_coefficient) {

    assert(ambient_coefficient >= 0.0);
    assert(diffuse_coefficient >= 0.0);
    assert(specular_coefficient >= 0.0);
  }

  // Accessors.
  constexpr double ambient_coefficient () const noexcept {
    return ambient_coefficient_ ;
  }
  constexpr const hdr_rgb& ambient_color() const noexcept {
    return ambient_color_;
  }
  constexpr double diffuse_coefficient () const noexcept {
    return diffuse_coefficient_;
  }
  constexpr double specular_coefficient() const noexcept {
    return specular_coefficient_;
  }

  virtual hdr_rgb shade(const scene& scene,
		                    const camera& camera,
		                    const intersection& xsect) const noexcept;
};

// A view ray represents a ray traveling from the viewer out into
// the scene. It is defined by an origin, and direction, each of
// which is a 3D vector.
class view_ray {
private:
  vector3<double> origin_, direction_;

public:

  // Constructor with an explicit origin and direction. Direction
  // must be normalized (magnitude 1).
  constexpr view_ray(const vector3<double>& origin,
                     const vector3<double>& direction) noexcept
  : origin_(origin),
    direction_(direction) { }

  // Accessors.
  constexpr const vector3<double>& origin() const noexcept {
    return origin_;
  }
  constexpr const vector3<double>& direction() const noexcept {
    return direction_;
  }
};

// Abstract class for some kind of scene object.
class abstract_scene_object {
private:
  hdr_rgb color_;
  double shininess_;

public:

  // Construct an object with the given diffuse color and shininesss
  // value (Phong exponent). shininess must be positive.
  constexpr abstract_scene_object(const hdr_rgb& color,
		                             double shininess) noexcept
  : color_(color),
    shininess_(shininess) {

    assert(shininess > 0.0);
  }

  virtual ~abstract_scene_object() noexcept = default;

  // Accessors.
  constexpr const hdr_rgb& color() const noexcept {
    return color_;
  }
  constexpr double shininess() const noexcept {
    return shininess_;
  }

  // Virtual function to find the intersection between this object
  // and the given viewing ray, if any.
  //
  // If no such intersection exists, return an empty optional.
  //
  // If there is an intersection within that t range, return an optional that
  // contains that intersection object.
  virtual std::optional<intersection> intersect(const view_ray& ray,
                                                double t_min,
                                                double t_upper_bound) const noexcept = 0;
};

// A scene object that is a 3D sphere.
class scene_sphere : public abstract_scene_object {
private:
  vector3<double> center_;
  double radius_;

public:

  // Create a sphere with the given color, shininess, center
  // location, and radius. radius must be positive.
  constexpr scene_sphere(const hdr_rgb& color,
	                       double shininess,
	                       const vector3<double>& center,
	                       double radius) noexcept
  : abstract_scene_object(color, shininess),
    center_(center),
    radius_(radius) {

    assert(radius > 0.0);
  }

  // Accessors.
  constexpr const vector3<double>& center() const noexcept {
    return center_;
  }
  constexpr double radius() const noexcept {
    return radius_;
  }

  virtual std::optional<intersection> intersect(const view_ray& ray,
                                                double t_min,
                                                double t_upper_bound) const noexcept;
};

// A scene object that is a 3D triangle.
class scene_triangle : public abstract_scene_object {
private:
  vector3<double> a_, b_, c_;

public:

  // The three vertices of the triangle are called a, b, c. Each is
  // a 3D location.
  constexpr scene_triangle(const hdr_rgb& color,
	                         double shininess,
	                         const vector3<double>& a,
	                         const vector3<double>& b,
	                         const vector3<double>& c) noexcept
  : abstract_scene_object(color, shininess),
    a_(a),
    b_(b),
    c_(c) { }

  // Accessors.
  constexpr const vector3<double>& a() const noexcept {
    return a_;
  }
  constexpr const vector3<double>& b() const noexcept {
    return b_;
  }
  constexpr const vector3<double>& c() const noexcept {
    return c_;
  }

  virtual std::optional<intersection> intersect(const view_ray& ray,
                                                double t_min,
                                                double t_upper_bound) const noexcept;
};

// A point_light represents a light source that gives off the same
// amount of light in all directions. The sun, or an idealized light
// bulb, can be modeled as a point light.
class point_light {
private:
  vector3<double> location_;
  hdr_rgb color_;
  double intensity_;

public:

  // Construct a point light at the given location, that emits light
  // of the given color, with the given scalar intensity. Intensity must
  // be positive.
  constexpr point_light(const vector3<double>& location,
	                      const hdr_rgb& color,
                        double intensity) noexcept
  : location_(location),
    color_(color),
    intensity_(intensity) {

    assert(intensity > 0.0);
  }

  // Accessors.
  constexpr const vector3<double>& location () const noexcept {
    return location_;
  }
  constexpr const hdr_rgb& color() const noexcept {
    return color_;
  }
  constexpr double intensity() const noexcept {
    return intensity_;
  }
};

// An intersection represents a place where a view ray hits a
// scene object. It is defined by:
//
// - a non-owning pointer to the object that was hit;
//
// - the 3D point where the hit occurs;
//
// - a normal vector, that is perpendicular to the object at the hit
//   location; and
//
// - the t value where the hit happened relative to the view ray
//   direction, i.e.
//       location == ray.origin + (t * ray.direction)
class intersection {
private:
  const abstract_scene_object *object_; // non-owning pointer
  vector3<double> location_, normal_;
  double t_;

public:

  // Construct an intersection.
  // The object pointer must not be nullptr.
  // The normal must be normalized (magnitude 1).
  constexpr intersection(const abstract_scene_object* object,
	                       const vector3<double>& location,
	                       const vector3<double>& normal,
	                       double t) noexcept
  : object_(object),
    location_(location),
    normal_(normal),
    t_(t) {

    assert(object != nullptr);
    assert(approx_equal(normal.magnitude(), 1.0, .01));
  }

  constexpr const abstract_scene_object& object() const noexcept {
    return *object_;
  }
  constexpr const vector3<double>& location() const noexcept {
    return location_;
  }
  constexpr const vector3<double>& normal() const noexcept {
    return normal_;
  }
  constexpr double t() const noexcept {
    return t_;
  }
};

scene scene::read_json(const std::string& path) noexcept(false) {

  auto import_vector = [](const rayson::vector3& v) noexcept {
    return vector3<double>{v.x(), v.y(), v.z()};
  };

  auto import_color = [](const rayson::color& c) noexcept {
    return hdr_rgb{float(c.r()), float(c.g()), float(c.b())};
  };

  try {

    rayson::scene loaded = rayson::read_file(path);

    std::unique_ptr<abstract_projection> the_projection;
    if (auto ortho = std::get_if<rayson::ortho_projection>(&loaded.projection())) {
      the_projection = std::make_unique<orthographic_projection>();
    } else if (auto persp = std::get_if<rayson::persp_projection>(&loaded.projection())) {
      the_projection = std::make_unique<perspective_projection>(persp->focal_length());
    } else {
      assert(false); // unknown projection type, should be unreachable
    }

    std::unique_ptr<abstract_shader> the_shader;
    if (auto flat = std::get_if<rayson::flat_shader>(&loaded.shader())) {
      the_shader = std::make_unique<flat_shader>();
    } else if (auto phong = std::get_if<rayson::phong_shader>(&loaded.shader())) {
      the_shader = std::make_unique<blinn_phong_shader>(phong->ambient_coeff(),
                                                        import_color(phong->ambient_color()),
                                                        phong->diffuse_coeff(),
                                                        phong->specular_coeff());
    } else {
      assert(false); // unknown shader type, should be unreachable
    }

    scene result(std::make_unique<::gfx::camera>(import_vector(loaded.camera().eye()),
                                                 import_vector(loaded.camera().view()),
                                                 import_vector(loaded.camera().up())),
                 std::make_unique<::gfx::viewport>(loaded.viewport().x_resolution(),
                                                   loaded.viewport().y_resolution(),
                                                   loaded.viewport().left(),
                                                   loaded.viewport().top(),
                                                   loaded.viewport().right(),
                                                   loaded.viewport().bottom()),
                 std::move(the_projection),
                 std::move(the_shader),
                 import_color(loaded.background()));

    for (auto& light : loaded.point_lights()) {
      result.add_light(std::make_unique<point_light>(import_vector(light.location()),
                                                     import_color(light.color()),
                                                     light.intensity()));
    }

    for (auto& sphere : loaded.spheres()) {
      result.add_object(std::make_unique<scene_sphere>(import_color(sphere.material().color()),
                                                       sphere.material().shininess(),
                                                       import_vector(sphere.center()),
                                                       sphere.radius()));
    }

    for (auto& tri : loaded.triangles()) {
      result.add_object(std::make_unique<scene_triangle>(import_color(tri.material().color()),
                                                         tri.material().shininess(),
                                                         import_vector(tri.a()),
                                                         import_vector(tri.b()),
                                                         import_vector(tri.c())));
    }

    return result;

  } catch (rayson::read_exception e) {
    throw scene_read_exception(path, e.message());
  }
}

///////////////////////////////////////////////////////////////////////////////
// START OF TODO
///////////////////////////////////////////////////////////////////////////////

std::optional<intersection> scene::intersect(const view_ray& ray) const noexcept {

    //  Set up the intersection object.
    std::optional<intersection> hit = std::nullopt;

    //  Set up the lower_limit as 0 and the upper_limit as infinity
    double lower_limit = 0;
    double upper_limit = std::numeric_limits<double>::infinity();
    //  Assume current t is infinity for now.
    double current_t = upper_limit;

    //  Loop through all objects in the scene and pass the ray lower limit and
    //  upper limit to them. The objects intersect functions will check if the
    //  ray hits them or not. (See those below)
    for (size_t i = 0; i < objects_.size(); ++i)
    {
        std::optional<intersection> potential_hit = objects_[i]->intersect(ray, lower_limit, current_t);
        //  If there was a hit and the hit was closer along the ray than anything else
        //  change hit to potential hit and current_t to the intersections t.
        if (potential_hit != std::nullopt && potential_hit.value().t() < current_t)
        {
            hit = potential_hit;
            current_t = potential_hit.value().t();
        }
    }

    return hit;
}

hdr_image scene::render() const noexcept {

    assert(camera_);
    assert(viewport_);
    assert(projection_);
    assert(shader_);

    assert(viewport_->x_resolution() > 0);
    assert(viewport_->y_resolution() > 0);

    size_t w = viewport_->x_resolution(),
         h = viewport_->y_resolution();

    //    Render the scene on the hdr_image object before creating a png of it.
    hdr_image result(w, h, background_);
    assert(!result.is_empty());

    //    Loop through each pixel in the image and compute it from the scene.
    for (size_t y = 0; y < h; ++y) {
        for (size_t x = 0; x < w; ++x) {


          //    Find the uv values.
          vector2<double> uv_values = viewport_->uv(x, y); //  viewport member of scene
          //    Use the uv values to compute the current ray.
          view_ray current_ray = projection_->compute_view_ray(*camera_, uv_values[0], uv_values[1]); //   projection member of scene
          //    Use the ray to find if anything intersects at that pixel.
          std::optional<intersection> hit = intersect(current_ray);

          //    If nothing intersects, color the that pixel based on the
          //    background color.
          if(hit == std::nullopt)
          {
              result.pixel(x, y, background_);
          }
          //    Else use a shader to find out what the pixels color should be
          else
          {
              result.pixel(x, y, shader_->shade(*this, *camera_, hit.value()));
          }

        }
    }

    return result;
}

constexpr camera::camera(const vector3<double>& eye,
	                       const vector3<double>& view_direction,
	                       const vector3<double>& up) noexcept {

    //    Set up the camera using the camera's position, the view direction,
    //    and a vector defining the scene's "up".
    //    Since up may not necessarily equal the up of the camera we need to
    //    compute it/
    eye_ = eye;
    //    W is the on the back camera, the exact opposite of the view direction.
    w_ = -(view_direction.normalized());
    //    U a vector perpendicular to both the scene up and the W.
    //    This would point towards the exact right of the camera.
    u_ = (up.cross(w_)).normalized();
    //    This it he last value which points up of the camera.
    v_ = (w_.cross(u_)).normalized();
}

vector2<double> viewport::uv(size_t x, size_t y) const noexcept {

    //  Compute the viewport of the scene. This refers to the screen.
    //  What objects will show up on the screen are defined by this function.
    //  This return a vector of two numbers, specifivally u and v.
    vector2<double> answer;

    answer[0] = left_ + (right_  - left_)*(x + 0.5) / x_resolution_;
    answer[1] = bottom_ + (top_ - bottom_)*(y + 0.5) / y_resolution_;

    return answer;
}

view_ray orthographic_projection::compute_view_ray(const camera& c,
					                                         double u,
					                                         double v) const noexcept {

    //    Compute the view_ray for an orthographic projection of the scene.
    //    Orthographic projection is perspective-less.
    vector3<double> origin = c.eye() + c.u() * u + c.v() * v;
    return view_ray(origin, -c.w());
}

view_ray perspective_projection::compute_view_ray(const camera& c,
					                                        double u,
					                                        double v) const noexcept {


    //    Compute the view_ray for a perspective projection of the scene.
    vector3<double> direction = c.w() * (-focal_length_) + c.u() * u + c.v() * v;
    return view_ray(c.eye(), direction);
}

hdr_rgb flat_shader::shade(const scene& scene,
			                     const camera& camera,
			                     const intersection& xsect) const noexcept {

    //    Flat shader. Does nothing by return the object's color.
    //    This is a simple place holder for when better shading is not
    //    valid or needed.
    return xsect.object().color();
}

hdr_rgb blinn_phong_shader::shade(const scene& scene,
				                          const camera& camera,
				                          const intersection& xsect) const noexcept {

    //    Get the intersected object's color
    hdr_rgb obj_color = xsect.object().color();

    //    Initialize each color channel to the ambient color, multiplied by the
    //    coefficient.
    double red_channel = ambient_color_.r() * ambient_coefficient_,
         green_channel = ambient_color_.g() * ambient_coefficient_,
         blue_channel = ambient_color_.b() * ambient_coefficient_;

    //    Create variables for the object normal and the view_direcion
    vector3<double> n = xsect.normal();   //  should be normalized already
    vector3<double> v = (camera.eye() - xsect.location()).normalized();
    //    k_d is the diffues coefficient,  I is the intensity of the light source
    //    l is the location,    n is the

    for (size_t i = 0; i < scene.lights().size(); ++i)
    {
        //    Create a location vector for the light,
        vector3<double> l = ((scene.lights()[i]->location() - xsect.location())).normalized();
        //    Find the half vector
        vector3<double> h = (v + l).normalized();

        //    The functions below are part of the blinn phong formula for shading
        //    Starting with an ambient color, add to it the sum over all lights,
        //    where each light is calculated in diffuse and specular terms

        //    For diffuse use the object's color, for specular use the light color.
        red_channel += diffuse_coefficient_ * obj_color.r() * std::max(0.0, n * l) +
             specular_coefficient_ * scene.lights()[i]->color().r() *
             pow(std::max(0.0, n * h), xsect.object().shininess());


        green_channel += diffuse_coefficient_ * obj_color.g() * std::max(0.0, n * l) +
             specular_coefficient_ * scene.lights()[i]->color().g() *
             pow(std::max(0.0, n * h), xsect.object().shininess());

        blue_channel += diffuse_coefficient_ * obj_color.b() * std::max(0.0, n * l) +
             specular_coefficient_ * scene.lights()[i]->color().b() *
             pow(std::max(0.0, n * h), xsect.object().shininess());

    }

    //    Clamping values here between 0 and 1
    //    We do not want to have values be greater than one or less then zero.
    //    (Additionally, hdr_rgb class has asserts set in place in case values
    //    go outside those bounds)
    red_channel = red_channel < 0 ? 0 : red_channel > 1 ? 1 : red_channel;
    green_channel = green_channel < 0 ? 0 : green_channel > 1 ? 1 : green_channel;
    blue_channel = blue_channel < 0 ? 0 : blue_channel > 1 ? 1 : blue_channel;


    //    Creae a new hdr_rgb to return to the render function.
    hdr_rgb pixel(red_channel, green_channel, blue_channel);

    return pixel;
}

std::optional<intersection>
  scene_sphere::intersect(
    const view_ray& ray,
    double t_min,
    double t_upper_bound) const noexcept {

    assert(t_min < t_upper_bound);

    //    *************************   Student work begins here.   ************

    //    This follows the formulat for intersrecting a sphere.
    //    The entire formula eventually collapses into a quadratic function.
    //    This makes sense because when a ray interersects with a sphere,
    //    it may intersect at two, one, or no points.

    //    Start by creating an answer variable.
    std::optional<intersection> answer;

    //    Set up origin and direction for ease of use.
    vector3<double> origin = ray.origin();
    vector3<double> direction = ray.direction();

    //    Set up center and radius for ease of use.
    vector3<double> center = center_;
    double radius = radius_;

    //    Quadratic function discriminant is B^2 - 4AC
    //    The sphere intersection formulat is slightly different but contains
    //    A similar idea.

    //    Find B and AC
    double B = (direction * (origin - center));
    double AC = direction * direction * ((origin - center)*(origin - center) - radius * radius);

    //    Use B and AC to find the discriminant.
    double discriminant = B * B - AC;

    //    If the discriminant is negative, the ray does not intersect.
    if (discriminant < 0)
    {
        answer = std::nullopt;
    }
    //    If the discriminant is 0 the ray  intersects at exactly one point
    //    This is often the extreme edge of the sphere.
    else if (discriminant == 0)
    {
        double t = -direction * (origin - center) / (direction * direction);
        if(t > t_upper_bound || t < t_min)
        {
          return std::nullopt;
        }
        vector3<double> location = origin + direction * t;
        vector3<double> norm = ((location - center_) * 2).normalized();
        answer = intersection(this, location, norm, t);
    }
    //    Else the discriminant is positive. When we square root it we get two values.
    else
    {
        discriminant = sqrt(discriminant);
        double first_t = (-direction * (origin - center) + discriminant) / (direction * direction);
        double second_t = (-direction * (origin - center) - discriminant) / (direction * direction);

        //    Choose the smaller t. This is closer to the ray's origin
        //    So closer to the camera.
        double smaller_t = first_t < second_t ? first_t : second_t;

        if(smaller_t > t_upper_bound || smaller_t < t_min)
        {
          return std::nullopt;
        }

        //    Set up the location using the ray equation e + d * t
        vector3<double> location = origin + direction * smaller_t;
        //    Set up the normal using the location and center.
        vector3<double> norm = ((location - center_) * 2).normalized();
        answer = intersection(this, location, norm, smaller_t);
    }

    return answer;
}

std::optional<intersection>
  scene_triangle::intersect(
    const view_ray& ray,
    double t_min,
    double t_upper_bound) const noexcept {

    assert(t_min < t_upper_bound);

    //    **************  Student work begins here.   ***************

    //    e is origin,   d is direction,
    //    assume x, y, z format for a b c in scene_triangle


    //    Original function is:
    //        e + t * d = a + (b - a) * beta + (c - a) * gamma
    //
    //    This is transformed into multiple statements one for each of the
    //    3-dimensional axii. (0, 1, 2) represent the (x, y, z) of the points of
    //    a vertex, where a_, b_, c_, are vectors representing the triangle vertices.

    //    Create a matrix representing A. This cotains the coefficients of the
    //    three equations that need to be solved.
    //    A * (b) = RH

    matrix<double, 3, 3> current {a_[0] - b_[0], a_[0] - c_[0], ray.direction()[0],
                                a_[1] - b_[1], a_[1] - c_[1], ray.direction()[1],
                                a_[2] - b_[2], a_[2] - c_[2], ray.direction()[2]};

    //    Create the right hand vector representing the "answer" if te matrix equation.
    //    This is RH
    vector3<double> right_hand{a_[0] - ray.origin()[0],
                             a_[1] - ray.origin()[1],
                             a_[2] - ray.origin()[2]};

    //    Create answer (b) which can e solved by using the matrix solve function.
    //    Solve function uses Cramer's Law to find the solution.
    vector3<double> answer = current.solve(right_hand);

    //    Split up the solution into t value, beta value, and gamma value
    double beta = answer[0];
    double gamma = answer[1];
    double t = answer[2];

    //    Check that the answer variables are withing allowable bounds.
    //    If they are not that means the ray did not intersect the triangle.
    //    Return a nullopt for the optional.
    if(t <= t_min || t >= t_upper_bound)
    {
        return std::nullopt;
    }
    if(gamma < 0 || gamma > 1)
    {
        return std::nullopt;
    }
    if(beta < 0 || beta > 1 - gamma)
    {
        return std::nullopt;
    }

    //    Plug in t into the ray equation to find the location of the intersection.
    //    Plugging in beta and gamma in to the other equation (found commented out)
    //    Is the equivalent.
    vector3<double> loc = ray.origin() + ray.direction() * t;//a_ + (b_ - a_) * beta + (c_ - a_) * gamma;

    //    Finding the normal of the surface. This is a unit vector that points to
    //    a direction perpendicular to the surface. For this we need two edges.

    //    Utilize the vertices to find two edges of the triangle.
    vector3<double> edge_one = b_ - a_;
    vector3<double> edge_two = c_ - a_;

    //    Find the cross product of the vertices to get a vector perpendicular to both.
    vector3<double> norm = edge_one.cross(edge_two).normalized();

    //    Set up the answer as an intersection with the information found.
    std::optional<intersection> inter = intersection(this, loc, norm, t);

    return inter;
}

} // namespace gfx
