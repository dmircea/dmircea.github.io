#include <stdexcept>
#include <string>
// #include <iostream>     //  Temporary library for debugging


namespace Aux
{
    template <typename T>
    class Vector_M
    {
    private:
        //  Array pointer defined at construction time / deleted at destruction time.
        T* m_array; //  Default is an array of one item.
        //  Size of the array used on demand.
        int m_size;  //  Default is one.
        //  Growth multiplier, used when the number of items becomes above the current
        //  maximum.
        short m_growth; //  Default if multiplier 2.
        //  Used to keep track of maximum number of elements.
        int m_max_size;  //  Deafult is one but grows based on grows multiplier.

        //  Private member functions go here
        void grow();
        void grow(int new_size);

    public:
        //  ------------------  Constructors and Destructors ------------------//
        constexpr Vector_M() noexcept;
        constexpr Vector_M(int max_size) noexcept;
        constexpr Vector_M(int max_size, short growth) noexcept;
        ~Vector_M();

        //  TODO --> Copy constructor
        constexpr Vector_M(const Vector_M & other);
        //  TODO --> Array constructor

        //  ------------------  Setters and Getters ---------------------------//

        constexpr int size          ()                          const noexcept;
        constexpr int max           ()                          const noexcept;
        constexpr int growth        ()                          const noexcept;

        constexpr T at              (int index)                 const;
        constexpr T& operator[]     (int index);

        //  Vector extension functionality
        constexpr void operator+=   (const Vector_M & right);

        //  Vector addition functionality
        constexpr Vector_M operator+(const Vector_M & right);

        //  Other vector operators
        constexpr void operator=    (const Vector_M & right);
        constexpr bool operator==   (const Vector_M & right)    const;

        //  ------------------  Funcionalities  -------------------------------//
        constexpr void push_back    (T val);
        constexpr Vector_M make_copy()                          const;
        constexpr void fill_from    (const Vector_M & other);
        constexpr bool isEqualTo    (const Vector_M & other)    const;
        constexpr bool isIdenticalTo(const Vector_M & other)    const;
        constexpr void clear        ();
        //  TODO --> to_string()
        //  TODO --> print() --> May not implement this
        //  TODO --> << overload for stream functonalities.

    };  //  End of Vector_M class

    //  -------------------------   IMPLEMENTATIONS ---------------------------//


    template <typename T>
    constexpr Vector_M<T>::Vector_M() noexcept
    : Vector_M(1)
    {
        // std::cout << "Default contructor." << std::endl;
    }

    template <typename T>
    constexpr Vector_M<T>::Vector_M(int max_size) noexcept
    : Vector_M(max_size, 2)
    {
        // std::cout << "Custom <max_size> contructor." << std::endl;
    }

    template <typename T>
    constexpr Vector_M<T>::Vector_M(int max_size, short growth) noexcept
    : m_max_size(max_size), m_growth(growth), m_size(0), m_array(new T[max_size])
    {
        // std::cout << "Custom <max_size, growth> contructor." << std::endl;
    }

    template <typename T>
    constexpr Vector_M<T>::Vector_M(const Vector_M<T> & other)
    : Vector_M(other.max(), other.growth())
    {
        fill_from(other);
    }

    template <typename T>
    Vector_M<T>::~Vector_M()
    {
        // std::cout << "Default destructor of size " << m_max_size << std::endl;
        if(m_array != nullptr)
        {
            delete[] m_array;
        }
    }

    //  ------------------  Setters and Getters ---------------------------//
    template <typename T>
    constexpr int Vector_M<T>::size() const noexcept
    {
        return m_size;
    }

    template <typename T>
    constexpr int Vector_M<T>::max() const noexcept
    {
        return m_max_size;
    }

    template <typename T>
    constexpr int Vector_M<T>::growth() const noexcept
    {
        return m_growth;
    }

    //  At function. Is constant function.
    template <typename T>
    constexpr T Vector_M<T>::at(int index) const
    {
        if(index < 0)
        {
            index += m_size;
        }
        if(index < 0)
        {
            throw std::out_of_range("Index was negative.");
        }
        if (index >= m_size)
        {
            throw std::out_of_range("Index was above maximum value of " +
                std::to_string(m_max_size) + ".");
        }
        return m_array[index];
    }

    template <typename T>
    constexpr void Vector_M<T>::push_back(T val)
    {
        //  Three statements.
        //  1. First increase size by one.
        //  2. If size ends up bigger than max, then growth happens
        //  3. Else, just put in val at size - 1 in the array;
        m_size++;
        if(m_size > m_max_size)
        {
            Vector_M::grow();
        }
        m_array[m_size - 1] = val;
    }

    template <typename T>
    constexpr Vector_M<T> Vector_M<T>::make_copy() const
    {
        Vector_M<T> new_copy;
        for (int i = 0; i < size(); ++i)
        {
            new_copy.push_back(at(i));
        }
        return new_copy;
    }

    template <typename T>
    constexpr void Vector_M<T>::fill_from(const Vector_M<T> & other)
    {
        for (int i = 0; i < other.size(); ++i)
        {
            push_back(other.at(i));
        }
    }

    template <typename T>
    constexpr void Vector_M<T>::clear()
    {
        m_max_size = 1;
        m_size = 0;
        delete[] m_array;
        m_array = new T[m_max_size];
    }

    template <typename T>
    void Vector_M<T>::grow()
    {
        int new_max_size = m_max_size * m_growth;
        grow(new_max_size);
    }

    template <typename T>
    void Vector_M<T>::grow(int new_size)
    {
        if(new_size <= m_max_size)
        {
            throw std::invalid_argument("The new size of " +
                std::to_string(new_size) + " is less or equal to " +
                std::to_string(m_max_size) + ".");
        }

        T * new_array = new T[new_size];

        for(int i = 0; i < m_max_size; ++i)
        {
            new_array[i] = m_array[i];
        }

        delete[] m_array;
        m_array = new_array;

        m_max_size = new_size;
    }

    template <typename T>
    constexpr bool Vector_M<T>::isEqualTo(const Vector_M<T> & other) const
    {
        if(m_size != other.size())
        {
            return false;
        }
        for (int i = 0; i < m_size; ++i)
        {
            if(at(i) != other.at(i))
            {
                return false;
            }
        }
        return true;
    }

    template <typename T>
    constexpr bool Vector_M<T>::isIdenticalTo(const Vector_M<T> & other) const
    {
        return (*this) == other && m_growth == other.growth();
    }

    template <typename T>
    constexpr T& Vector_M<T>::operator[] (int index)
    {
        if(index < 0)
        {
            index += m_size;
        }
        if(index < 0)
        {
            throw std::out_of_range("Index was negative.");
        }
        if (index >= m_size)
        {
            throw std::out_of_range("Index was above maximum value of " +
                std::to_string(m_max_size) + ".");
        }
        return m_array[index];
    }

    template <typename T>
    constexpr void Vector_M<T>::operator+= (const Vector_M<T> & right)
    {
        for (int i = 0; i < right.size(); ++i)
        {
            push_back(right.at(i));
        }
    }

    template <typename T>
    constexpr bool Vector_M<T>::operator==(const Vector_M<T> & right) const
    {
        return (*this).isEqualTo(right) && m_max_size == right.max();
    }

    template <typename T>
    constexpr Vector_M<T> Vector_M<T>::operator+ (const Vector_M<T> & right)
    {
        Vector_M<T> answer(*this);

        answer.fill_from(right);

        return answer;
    }

    template <typename T>
    constexpr void Vector_M<T>::operator=(const Vector_M<T> & right)
    {
        clear();
        // std::cout << "Inside = operator\n";
        m_max_size = right.max();
        m_growth = right.growth();
        delete[] m_array;
        m_array = new T[m_max_size];
        // std::cout << "Inside = operator before fill_from\n";
        fill_from(right);
        // std::cout << "After fill_from and exiting = operator\n";
    }


}   //  End of aux namespace
