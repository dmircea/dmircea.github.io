#include "Vector_M.hpp"
#include <iostream>
#include <gtest/gtest.h>

using namespace Aux;

/*
    INTRO
    This program was created by Mircea Dumitrache, student assistant at CSUF.

    PURPOSE
    The purpose of this program is to mimic the functionalities of the
    vector data type found in the STL, and to create an appropriate
    unit test around this project.

    REASON
    This project was originally my method of building the vector data structure
    using my own reasoning and though process. Eventually, I decided to use
    this project to learn how to use the gtest library.

    DEPENDENCIES
    The hpp file containing the Vector_Mimic class depends on the string library,
    and may depend on the stream library. (The to_string function and operator<<
    overload function)
    The main.cpp file depends on the gtest library.
    The gtest library also depends on the pthread library.

    Please make certian that those libraries are installed if you wish to
    run the tests. Otherwise, the hpp file can be used without them.

    ADDITIONAL INFO
    A make.py script created in python is given alongside this project for
    simple compilation. To use it, it is suggested to have the latest version
    of python3 installed on the computer and added to the path file.

    Either use. "./make.py" or "python3 make.py" to run the make script.

    Alternatively, feel free to use the following linux command:

    clang++ main.cpp -o main -lgtest -lpthread

    FUTURE UPDATES
    Create proper documentation for this data structure.
*/

class VectorMTest : public ::testing::Test {
    //  Setting up testing equipment
protected:
    Vector_M<int> empty;
    Vector_M<int> only_one;
    Vector_M<int> two_elem;
    Vector_M<int> three_elem;
    Vector_M<int> ten_elem;

    Vector_M<int> hundred_elem;

    Vector_M<int> * ptr_vector;
    Vector_M<int> * ptr_vector_later;
public:
    VectorMTest()
    {
        ptr_vector = new Vector_M<int>;
        ptr_vector_later = nullptr;
    }
    //  Cleaning up after testing with no exceptions.
    ~VectorMTest() override
    {
        delete ptr_vector;

        //  Check if the other ptr contains something
        if(ptr_vector_later != nullptr)
        {
            delete ptr_vector_later;
            ptr_vector_later = nullptr;
        }
    }
};

TEST_F(VectorMTest, StaticEmptyVectorIsEmpty)
{
    EXPECT_EQ(empty.size(), 0);
    EXPECT_EQ(only_one.size(), 0);
    EXPECT_EQ(two_elem.size(), 0);
    EXPECT_EQ(three_elem.size(), 0);
    EXPECT_EQ(ten_elem.size(), 0);
    EXPECT_EQ(hundred_elem.size(), 0);
    EXPECT_EQ(ptr_vector->size(), 0);
}
TEST_F(VectorMTest, ContructorWorksAsIntended)
{
    ASSERT_EQ(ptr_vector_later, nullptr);

    ptr_vector_later = new Vector_M<int>;

    ASSERT_NE(ptr_vector_later, nullptr);

    delete ptr_vector_later;
    ptr_vector_later = nullptr;
}

TEST_F(VectorMTest, PushBackOneElement)
{
    only_one.push_back(5);
    ASSERT_EQ(only_one.size(), 1);
    ASSERT_EQ(only_one[0], 5);
    ASSERT_EQ(only_one.at(0), 5);
    ASSERT_EQ(only_one.max(), 1);

    EXPECT_THROW(only_one[1], std::out_of_range);
}

TEST_F(VectorMTest, PushBackTwoElements)
{
    two_elem.push_back(11);
    two_elem.push_back(99);

    ASSERT_EQ(two_elem.size(), 2);
    ASSERT_EQ(two_elem.max(), 2);

    ASSERT_EQ(two_elem[0], 11);
    ASSERT_EQ(two_elem[1], 99);

    ASSERT_EQ(two_elem.at(0), 11);
    ASSERT_EQ(two_elem.at(1), 99);
    ASSERT_EQ(two_elem.at(-1), 99);
    ASSERT_EQ(two_elem.at(-2), 11);

    ASSERT_THROW(two_elem.at(3), std::out_of_range);
    ASSERT_THROW(two_elem.at(-3), std::out_of_range);
}

TEST_F(VectorMTest, PushBackThreeElements)
{
    three_elem.push_back(12);
    three_elem.push_back(23);
    three_elem.push_back(100);

    //  12  23  100

    ASSERT_EQ(three_elem.size(), 3);
    ASSERT_EQ(three_elem.max(), 4);

    ASSERT_EQ(three_elem[2], 100);
    ASSERT_EQ(three_elem[-1], 100);

    ASSERT_EQ(three_elem.at(2), 100);
    ASSERT_EQ(three_elem.at(-1), 100);

    ASSERT_THROW(three_elem.at(5), std::out_of_range);
    ASSERT_THROW(three_elem.at(-5), std::out_of_range);
}

TEST_F(VectorMTest, PushBackTenElements)
{
    for (int i = 0; i < 10; ++i)
    {
        ten_elem.push_back(i);
    }

    ASSERT_EQ(ten_elem.size(), 10);
    ASSERT_EQ(ten_elem.max(), 16);

    for (int i = 0; i < ten_elem.size(); ++i)
    {
        ASSERT_EQ(ten_elem[i], i);
        ASSERT_EQ(ten_elem.at(i), i);
    }

    for (int i = 1; i <= ten_elem.size(); ++i)
    {
        ASSERT_EQ(ten_elem[-i], ten_elem.size() - i);
        ASSERT_EQ(ten_elem.at(-i), ten_elem.size() - i);
    }
}

TEST_F(VectorMTest, PushBackOneHundredElements)
{
    for (int i = 0; i < 100; ++i)
    {
        hundred_elem.push_back(i);
    }

    ASSERT_EQ(hundred_elem.size(), 100);
    ASSERT_EQ(hundred_elem.max(), 128);

    for (int i = 1; i <= 100; ++i)
    {
        ASSERT_EQ(hundred_elem[i - 1], i - 1);
        ASSERT_EQ(hundred_elem[-i], hundred_elem.size() - i);
    }
}

TEST_F(VectorMTest, EqualSettingsOfVector)
{
    {
        Vector_M<int> first;
        ASSERT_EQ(first.size(), 0);
        ASSERT_EQ(first.max(), 1);
        ASSERT_EQ(first.growth(), 2);
    }

    {
        Vector_M<int> second(32);
        ASSERT_EQ(second.size(), 0);
        ASSERT_EQ(second.max(), 32);
        ASSERT_EQ(second.growth(), 2);
    }

    {
        Vector_M<int> third(32, 5);
        ASSERT_EQ(third.size(), 0);
        ASSERT_EQ(third.max(), 32);
        ASSERT_EQ(third.growth(), 5);
    }
}

TEST_F(VectorMTest, ExtensionUsingPlusEqualOperator)
{
    const int ARR_SIZE = 10;
    const int array[] = {5, 12, 13, 15, 23, 26, 37, 42, 51, 69};
    Vector_M<int> first_half;
    Vector_M<int> second_half;

    for (int i = 0; i < ARR_SIZE / 2; ++i)
    {
        first_half.push_back(array[i]);
    }
    for (int i = ARR_SIZE / 2; i < ARR_SIZE; ++i)
    {
        second_half.push_back(array[i]);
    }

    ASSERT_EQ(first_half.size(), ARR_SIZE / 2);
    ASSERT_EQ(first_half.at(3), array[3]);
    ASSERT_EQ(second_half.at(3), array[8]);
    ASSERT_THROW(first_half.at(5), std::out_of_range);

    first_half += second_half;

    ASSERT_EQ(first_half.size(), ARR_SIZE);
    ASSERT_EQ(first_half.at(3), array[3]);
    ASSERT_EQ(first_half.at(8), second_half.at(3));
}

TEST_F(VectorMTest, UsingCopyFunction)
{
    Vector_M<int> temp;

    temp.push_back(3);
    temp.push_back(5);
    temp.push_back(10);

    Vector_M<int> made_using_copy = temp.make_copy();

    ASSERT_EQ(made_using_copy.at(0), temp.at(0));
    ASSERT_EQ(made_using_copy.at(1), temp.at(1));
    ASSERT_EQ(made_using_copy.at(2), temp.at(2));

    Vector_M<int> made_using_copy_constructor(made_using_copy);

    ASSERT_EQ(made_using_copy_constructor.at(0), made_using_copy.at(0));
    ASSERT_EQ(made_using_copy_constructor.at(1), made_using_copy.at(1));
    ASSERT_EQ(made_using_copy_constructor.at(2), made_using_copy.at(2));

    Vector_M<int> made_using_assignment = made_using_copy_constructor;

    ASSERT_EQ(made_using_assignment.at(0), made_using_copy_constructor.at(0));
    ASSERT_EQ(made_using_assignment.at(1), made_using_copy_constructor.at(1));
    ASSERT_EQ(made_using_assignment.at(2), made_using_copy_constructor.at(2));
}

TEST_F(VectorMTest, EqualSettingsCopyFunctionality)
{
    Vector_M<int> original;
    Vector_M<int> first_copy(original);
    Vector_M<int> second_copy = original;

    ASSERT_EQ(first_copy.max(), original.max());
    ASSERT_EQ(second_copy.max(), original.max());
    ASSERT_EQ(first_copy.growth(), original.growth());
    ASSERT_EQ(second_copy.growth(), original.growth());

    Vector_M<int> another(55, 4);
    Vector_M<int> third_copy(another);
    Vector_M<int> fourth_copy = another;
    second_copy = another;

    ASSERT_EQ(third_copy.max(), another.max());
    ASSERT_EQ(third_copy.growth(), another.growth());
    ASSERT_EQ(fourth_copy.max(), another.max());
    ASSERT_EQ(fourth_copy.growth(), another.growth());
    ASSERT_EQ(second_copy.max(), another.max());
    ASSERT_EQ(second_copy.growth(), another.growth());
}

TEST_F(VectorMTest, UsingAssignmentOperator)
{
    Vector_M<int> original;
    Vector_M<int> other(original);

    for (int i = 0; i < 10; ++i)
    {
        original.push_back(i);
    }
    other.push_back(33);
    other.push_back(44);
    other.push_back(55);

    ASSERT_NE(original.size(), other.size());
    ASSERT_NE(original[0], other[0]);

    other = original;

    ASSERT_EQ(original.size(), other.size());
    ASSERT_EQ(original[0], other[0]);
}

TEST_F(VectorMTest, UsingPlusOperator)
{
    Vector_M<int> first;
    Vector_M<int> second;

    first.push_back(0);
    first.push_back(11);
    first.push_back(222);
    first.push_back(3333);
    first.push_back(44444);

    second.push_back(0);
    second.push_back(11);
    second.push_back(222);
    second.push_back(3333);
    second.push_back(44444);

    Vector_M<int> third = first + second;

    ASSERT_EQ(third.size(), first.size() + second.size());

    Vector_M<int> fourth = first + second + third;

    ASSERT_EQ(fourth.size(), first.size() + second.size() + third.size());

    Vector_M<int> fifth = fourth + fourth + fourth + fourth;

    ASSERT_EQ(fifth.size(), fourth.size() * 4);
}

TEST_F(VectorMTest, IsEqualToFunction)
{
    Vector_M<int> first, second;

    for (int i = 0; i < 20; i+=2)
    {
        first.push_back(i);
        second.push_back(i);
    }

    ASSERT_TRUE(first.isEqualTo(second));

    second.push_back(123);

    ASSERT_FALSE(first.isEqualTo(second));
}

TEST_F(VectorMTest, EqualityOperator)
{
    Vector_M<int> first, second;

    for (int i = 0; i < 20; i+=2)
    {
        first.push_back(i);
        second.push_back(i);
    }

    ASSERT_TRUE(first == second);

    second.push_back(123);

    ASSERT_FALSE(first == second);
}

TEST_F(VectorMTest, IsIdenticalToFunction)
{
    Vector_M<int> first, second;
    Vector_M<int> third(33, 9);

    for (int i = 0; i < 20; i+=2)
    {
        first.push_back(i);
        second.push_back(i);
        third.push_back(i);
    }

    ASSERT_TRUE(first.isEqualTo(second));
    ASSERT_TRUE(first.isEqualTo(third));

    ASSERT_TRUE(first == second);
    ASSERT_FALSE(first == third);

    ASSERT_TRUE(first.isIdenticalTo(second));
    ASSERT_FALSE(first.isIdenticalTo(third));

}


TEST_F(VectorMTest, UsingPointerVector)
{
    ASSERT_EQ(ptr_vector->size(), 0);
    ASSERT_EQ(ptr_vector->max(), 1);

    ptr_vector->push_back(10);
    ptr_vector->push_back(20);
    ptr_vector->push_back(30);

    ASSERT_EQ(ptr_vector->size(), 3);
    ASSERT_EQ(ptr_vector->max(), 4);

    ASSERT_EQ((*ptr_vector)[0], 10);
    ASSERT_EQ((*ptr_vector)[-1], 30);

}

TEST_F(VectorMTest, UsingVectorOfPointers)
{
    Vector_M<int*> vector_of_ptr;

    for (int i = 0; i < 10; ++i)
    {
        vector_of_ptr.push_back(new int(i));
    }

    ASSERT_EQ(vector_of_ptr.size(), 10);

    ASSERT_EQ(*vector_of_ptr[0], 0);
    ASSERT_EQ(*vector_of_ptr[9], 9);

    for (int i = 0; i < 10; ++i)
    {
        delete vector_of_ptr[i];
        vector_of_ptr[i] = nullptr;
    }
}




int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
