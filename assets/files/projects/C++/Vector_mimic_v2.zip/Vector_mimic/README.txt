INTRO
This program was created by Mircea Dumitrache, student assistant at CSUF.

PURPOSE
The purpose of this program is to mimic the functionalities of the
vector data type found in the STL, and to create an appropriate
unit test around them.

REASON
This project was originally my method of building the vector data structure
using my own reasoning and thought process. Eventually, I decided to use
this project to learn how to use the gtest library, and made a simplified
version of the Vector data structure instead.

By simplified, I am referring to the use of an array pointer, as opposed to
the use of a pointer to pointer variable. However this may be the next update.

DEPENDENCIES
The Vector_M.hpp file containing the Vector_Mimic class depends on the string library,
and may depend on the stream library in the future.

The main.cpp file depends on the gtest library.
The gtest library also depends on the pthread library.

Please make certian that those libraries are installed if you wish to
run the tests. Otherwise, the hpp file can be used without them.

ADDITIONAL INFO
A make.py script created in python is given alongside this project for
simple compilation. To use it, it is suggested to have the latest version
of python3 installed on the computer and added to the path file.

Either use. "./make.py" or "python3 make.py" to run the make script.

Alternatively, feel free to use the following linux command:

clang++ main.cpp -o main -lgtest -lpthread

FUTURE UPDATES
Create proper documentation for this data structure.
Create the stream functionality for output.
Refactor the code to utilize a pointer to pointer data as it's array.
