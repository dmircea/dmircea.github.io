#include <iostream>
#include <iomanip>
#include <mpi.h>

#include "headers.hpp"
#include "p_info.hpp"

int main(int argc, char ** argv)
{
	/*
			PROGRAM INITIALIZATION SECTION
	*/
	if(argc != 2)
	{
		std::cout << "Usage: ./exectuable data_file.txt" << std::endl;
		std::cout << "If using MPI to run this then try the following:\n";
		std::cout << "mpirun -n <number_of_processes> ./exectuable data_file.txt\n";
		std::cout << "Examples:\n";
		std::cout << "mpirun -n 1 ./main data/test_data1.txt\n";
		std::cout << "mpirun -n 4 ./main data/test_data2.txt\n";
		
		//	Finish MPI and quit here
		//	MPI_Finalize();
		exit(1);
	}

	std::string filename = argv[1];


	long * matrix_data = nullptr;
	int size = 0;

	//	Load the data or exit if unsuccessful.
	matrix_data = load_data(filename, size);
	if(matrix_data == nullptr)
	{
		//	Exit from all proceses and return
		exit(1);
	}

	/*
		MPI INITIALIZATION SECTION
	*/
	int ierr = MPI_Init(&argc, &argv);

	//	Check for any issues
	if(ierr != 0)
	{
		std::cout << "There was an error when initializing MPI\n";
		std::cout << "Exiting...\n";
		exit(1);
	}

	Process_Information p_info;

	p_info.num_of_uses = 0;

	//	Get number of processes
	ierr = MPI_Comm_size(MPI_COMM_WORLD, &p_info.processes);
	ierr = MPI_Comm_rank(MPI_COMM_WORLD, &p_info.id);

	//	Load the data from file into the appropriate structure
	//	Will probably use a vector, (but resize it to n)
	

	if(p_info.id == 0)
	{
		std::cout << "The number of processes is " << p_info.processes << std::endl; 
		
		if(size < 15)
		{
			std::cout << "This is the data that will be computed:\n";
			printMatrix(matrix_data, size);
		}
		else
		{
			std::cout << "The matrix size is too big to be shown.\n";
		}

	}	//	End if id == 0

	//
	if(p_info.processes > 1)
	{
		/*
			Main variable initialization for all processes
		*/
		p_info.start = MPI_Wtime();
		long loc = 0, loc_final = 0;
		long val = -1, val_final = -1;
		long ans[4] = { -1 };
		long ans_final[4] = { -1 };
		long * sub_matrix = new long[size * 2];

		//	This will be used only in the loop
		short left_over_rows = size;
		int iteration = 1;

		//	At this point I should loop through based on the number of processes available
		//	Each process will deal with 2 sections (1 section = base row and the row directly below)
		//	However the row directly below will not be counted due to the nature of the problem

		//	The size here refers more to the number of rows in the matrix
		for (int rows = 0; rows < size - 1; rows += (p_info.processes * 2))
		{

			//	Scatter the current section of the array
			//	This is based on array start, and the current iteration of the loop
			MPI_Scatter(matrix_data + (rows * size), size * 2, MPI_LONG, sub_matrix, size * 2, MPI_LONG, 0, MPI_COMM_WORLD);

			//	This checks that the node does not try to use the algorithm 
			//	on parts of the array that do not exits
			//		Explanation: Think when 4 rows are left, but 8 nodes do work. One node does work
			//					 for 2 rows here so only 2 nodes should still work at all
			if(left_over_rows / 2 > p_info.id)
			{
				val = mpi_row_algo(sub_matrix, ans, size, p_info, loc);
			}

			if(val > val_final)
			{
				ans_final[0] = ans[0];
				ans_final[1] = ans[1];
				ans_final[2] = ans[2];
				ans_final[3] = ans[3];

				val_final = val;
				loc_final = loc;
				iteration = (rows / (p_info.processes * 2));
			}

			//	This is neccesary so that the next row can pinpoint correct location
			loc = size;

			//	Scatter the next set of rows (think of previous given rows but shifted once down by one)
			MPI_Scatter(matrix_data + (rows * size) + size, size * 2, MPI_LONG, sub_matrix, size * 2, MPI_LONG, 0, MPI_COMM_WORLD);

			//	If there are less rows to be computed than the total number of computable rows
			if (left_over_rows <= p_info.processes * 2)
			{
				if(size % 2 == 0 && left_over_rows / 2 - 1 > p_info.id)	//	Even rows
				{	
					//	Take out one more process
					val = mpi_row_algo(sub_matrix, ans, size, p_info, loc);
				}
				else if(size % 2 == 1 && left_over_rows / 2 > p_info.id) //	Odd rows so one more process should be able to shift
				{
					val = mpi_row_algo(sub_matrix, ans, size, p_info, loc);
				}
			}
			else //	Still enough for everyone
			{
				val = mpi_row_algo(sub_matrix, ans, size, p_info, loc);
			}

			if(val > val_final)
			{
				ans_final[0] = ans[0];
				ans_final[1] = ans[1];
				ans_final[2] = ans[2];
				ans_final[3] = ans[3];

				val_final = val;
				loc_final = loc;
				iteration = (rows / (p_info.processes * 2));
			}

			//	Take off the rows done from left_over_rows
			left_over_rows -= p_info.processes * 2;

		}	//	END for loop through rows

		loc_final += size * 2 * (p_info.id) + iteration * size * 2 * p_info.processes;

		long return_data[6] = {ans_final[0], ans_final[1], ans_final[2], ans_final[3], val_final, loc_final};

		long * final_data = nullptr;
		if(p_info.id == 0)
		{
			final_data = new long[p_info.processes * 6];
		}

		MPI_Gather(return_data, 6, MPI_LONG, final_data, 6, MPI_LONG, 0, MPI_COMM_WORLD);

		if(p_info.id == 0)
		{
			for(int i = 0; i < p_info.processes * 6; i+=6)
			{
				if(val_final < final_data[i + 4])
				{
					ans_final[0] = final_data[i + 0];
					ans_final[1] = final_data[i + 1];
					ans_final[2] = final_data[i + 2];
					ans_final[3] = final_data[i + 3];
					val_final = final_data[i + 4];
					loc_final = final_data[i + 5];
				}
			}

			//	Calculate the row and collumn from given array location
			int row = loc_final / size;
			int col = loc_final % size;

			std::cout << "\nThe largest sum was " << val_final << ".\n";
			std::cout << "Here is the found 2x2 matrix: \n";
			printMatrix(ans_final, 2);

			std::cout << "\nIn the original matrix the upper left value of this 2x2 "
					  << "matrix can be found at (row=" << row + 1 << ", col=" << col + 1 << ").\n"; 
			
			//	This should only be pointing if root node.
			delete[] final_data;
			final_data = nullptr;
		}

		//	Delete this for all processes
		delete[] sub_matrix;
		sub_matrix = nullptr;

		p_info.stop = MPI_Wtime();
	}	//	End if processes > 1
	else
	{
		p_info.start = MPI_Wtime();
		//	Run the simple version of the algo here.
		long ans[4];
		long loc = -1;
		long val = base_algo(matrix_data, ans, size, loc);

		int row = loc / size;
		int col = loc % size;

		p_info.stop = MPI_Wtime();

		std::cout << "\nThe largest sum was " << val << ",\n";
		std::cout << "Here is the found 2x2 matrix: \n";
		printMatrix(ans, 2);
		
		std::cout << "\nIn the original matrix the upper left value of this 2x2 "
					  << "matrix can be found at (row=" << row + 1 << ", col=" << col + 1 << ").\n"; 
	}
	//	Free memory
	delete[] matrix_data;
	matrix_data = nullptr;

	MPI_Finalize();


	p_info.time = p_info.stop - p_info.start;

	if(p_info.id == 0)
	{
		std::cout << "\nThe ammoun of time it took until completion: " << p_info.time << std::endl;
	}

	return 0;
}

void printMatrix(long * matrix, int size)
{
	if(matrix == nullptr)
	{
		std::cout << "No data found!\n";
		return;
	}
	for(int i = 0; i < size * size; ++i)
	{
		if(i % size == 0)
		{
			std::cout << std::endl;
		}
		std::cout << std::setw(5) << matrix[i] << ' ';
	}
}