#pragma once
#include <string>
#include <vector>

#include "p_info.hpp"

const std::string PATH = "data/";	//	May not be used

void printMatrix(long * matrix, int size);

long * load_data(const std::string & filename, int & size);
long base_algo(long * data, long answer[4], int size, long & index);
long mpi_row_algo(long * data, long answer[4], int size, Process_Information & p_info, long & index);
