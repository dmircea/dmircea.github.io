#include "headers.hpp"

long base_algo(long * data, long answer[4], int size, long & index)
{
	//	Init sum to very first box
	if(data == nullptr)
	{
		return -1;
	}
	if(size * size < 4)
	{
		return -1;
	}

	long largest_sum = data[0] + data[1] + data[0 + size] + data[1 + size];
	answer[0] = data[0];
	answer[1] = data[1];
	answer[2] = data[0 + size];
	answer[3] = data[1 + size];
	index = 0;

	//	Loop through the box
	for(int i = 0; i < size * size - size; ++i)
	{
		//	To make sure the edges are not counted together
		if(i % size == size - 1)
		{
			continue;
		}

		long current_sum = data[i] + data[i + 1] + data[i + size] + data[i + 1 + size];
		//	Check if new highest
		if(current_sum > largest_sum)
		{
			//	Change the variables
			largest_sum = current_sum;
			answer[0] = data[i];
			answer[1] = data[i + 1];
			answer[2] = data[i + size];
			answer[3] = data[i + 1 + size];
			index = i;
			//	Mod by size gives you columns
			//	Divide by size gives you rows
		}
	
	}
	return largest_sum;
}