# 474-Project-2
Project 2 for CPSC 474.01

## Group members:
Mircea Dumitrache --> dmircea@csu.fullerton.edu

## Introduction

This project was created for CPSC 474 Parallel and Distributed Computing as an introduction to 
MPI. It is mainly written in C (with a bit of C++) and makes use of the MPI bindings to emulate
separate nodes on one computer.

### Testing
This program was tested on Xubuntu (Tuffix version).
Theoretically it should work on any Linux OS. 
While not tested, it MAY work on MacOS or Windows given that the neccessary libraries are installed.

### Requirements
The program requires the following:
- C++ compiler that includes C++11 standard.
- MPI headers (see below for installation info)

### NOTE
This program assumes the ammount of RAM available in the computer will be enough for completion.
It will not check for bounds in matrix size or restrict the number of nodes to be used.

## Installation
A proper C++ compiler should be automatically installed on most Linux machines.

In order to install MPI please use the following apt command:
`sudo apt install mpich` 
OR
`sudo apt-get install mpich2`

Once the command finishes successfully please use 'which mpiCC' to make sure that the 
the command was installed correctly.

## Compilation and execution

Information on how to run the program:

* To compile use the following command:
	`mpiCC -std=c++11 -o main main.cpp load_data.cpp base_algo.cpp mpi_algo.cpp`
* To run the program us the following command template:
	`mpirun -n <number of processes> ./main <text file including size and matrix>`
* Examples of run commands:
	`mpirun -n 1 ./main data/test_data1.txt`
	`mpirun -n 4 ./main data/test_data2.txt`

## Data randomization

The data_maker folder contains a simple c++ program to create randomized data set for an x by x matrix.

* To compile the program use the following command:
	`g++ data.cpp -o data`
* To run the program use the following command:
	`./data <size of wanted matrix - optional>`

If no size is specified it assumes the default of 50.
NOTE: Please be aware that the program has not proper size limit. If the number one million is given
it WILL attempt to creat a one million by one million matrix.

## Some data

At a matrix size of 1000 the MPI version begins to be faster than the base algorithm.
> Base version timing:	0.0270098  ||
> MPI version timing:	0.0203901

At a matrix size of 10,000 the base algorithm gave a time of 50 seconds, but the MPI version crashed due to
a segmentation fault. This is likely because the MPI version attempted to reserve additional RAM and ran out.
(The linux machine I developed this program on has 4GB of RAM.)
