#pragma once

struct Process_Information
{
	int processes;
	int id;
	double time, start, stop;
	int num_of_uses;
};