#include "headers.hpp"
#include <fstream>
#include <iostream>


/*
	TODO:
	Create an fstream variable to read from a file
	read all data and place it into data_holder (make sure to resize the vectors given n)

*/
long * load_data(const std::string & filename, int & size)
{
	std::ifstream in(filename);
	long * data_holder = nullptr;

	//	Check if file open and good
	if(!in.is_open())
	{
		std::cout << "File could not be opened!\n";
		return nullptr;
	}

	//	Get the size of the matrix
	in >> size;
	data_holder = new long[size * size];
	
	//	This is the number of elements
	int count = size * size;

	//	Get stuff from the file
	for (int i = 0; i < size * size; ++i)
	{
		in >> data_holder[i];
		count--;
	}

	if(count != 0)
	{
		std::cout << "Something is wrong with the matrix in the file.\n";
		delete[] data_holder;
		return nullptr;
	}

	in.close();

	return data_holder;
}