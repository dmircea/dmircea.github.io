#include <iostream>
#include <fstream>
#include <random>
#include <time.h>

int main(int argc, char ** argv)
{
	int matrix_size = 0;

	if(argc == 1)
	{
		matrix_size = 50;
	}
	else
	{
		std::string temp = argv[1];
		matrix_size = std::stoi(temp);
	}

	srand(time(0));

	std::ofstream out("../data/randomized_data.txt");

	if(!out.is_open())
	{
		std::cout << "Could not open file!\n";
		return 0;
	}

	out << matrix_size << std::endl;

	for(int i = 0; i < matrix_size; ++i)
	{
		for (int j = 0; j < matrix_size; ++j)
		{
			int random_int = rand() % 30000 + 500;
			out << random_int << ' ';
		}
		out << std::endl;
	}

	out.close();

	return 0;
}