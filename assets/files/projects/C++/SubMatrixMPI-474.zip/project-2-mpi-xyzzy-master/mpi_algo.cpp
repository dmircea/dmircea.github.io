#include "headers.hpp"
#include <iostream>
#include <mpi.h>

//	unlike base algo, assume the size of data is twice the ammount of variable size
long mpi_row_algo(long * data, long answer[4], int size, Process_Information & p_info, long & index)
{
	if(data == nullptr)
	{
		std::cout << "Rank " << p_info.id << " process has no data. Exiting.\n";
		return -1;
	}
	//	Set up mpi for this algorithm using program parameters
	long largest_sum = data[0] + data[1] + data[0 + size] + data[1 + size];
	answer[0] = data[0];
	answer[1] = data[1];
	answer[2] = data[0 + size];
	answer[3] = data[1 + size];

	if(index != size)
	{
		index = 0;
	}
		
	for (int i = 0; i < size - 1; ++i)
	{
		long current_sum = data[i] + data[i + 1] + data[i + size] + data[i + 1 + size];
		//	Check if new highest
		if(current_sum > largest_sum)
		{
			//	Change the variables
			largest_sum = current_sum;
			answer[0] = data[i];
			answer[1] = data[i + 1];
			answer[2] = data[i + size];
			answer[3] = data[i + 1 + size];
			index = i;
			//	Mod by size gives you columns
			//	Divide by size gives you rows
		}
	}
	
	return largest_sum;
}