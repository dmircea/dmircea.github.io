#include <iostream>
#include <string>
#include <fstream>

/*
    This program was created by Mircea Dumitrache as a joke program.

    Originally, I saw a program on github that contained a python script
    of about 10,000 lines of code. The entire script seemed ridiculous
    because all it had were if statements upon if statements that checked if
    the input was this number and this number, output this answer.

    This lead me to think that he made it as a joke using another program.

    So, I eventually decided to try it too, since it seemed fun.

    This program is useless, but was fun to make it.
*/

int main()
{
    const int RIGHT_NUM = 100;
    const int LEFT_NUM = 100;

    // std::string filename;
    // std::cout << "Please type the name of the file you want to create: ";
    // std::cin >> filename;


    std::ofstream toProgram("math.cpp");

    if(!toProgram.is_open())
    {
        std::cout << "The file could not be opened. Ending program..." << std::endl;
        return 0;
    }

    toProgram << "#include <iostream>\n";
    toProgram << "int main()\n{\n";

    toProgram << "\tint x;\n";
    toProgram << "\tint y;\n\n";
    toProgram << "\tstd::cout << \"Please type in the first and second number you want to multiply: \";\n";
    toProgram << "\tstd::cin >> x >> y;\n\n";


    for (int i = 0; i < RIGHT_NUM; i++)
    {
        for (int j = 0; j < LEFT_NUM; j++)
        {
            toProgram << "\tif (x == " << i << " && y == " << j << ")\n";
            toProgram << "\t{\n";

            toProgram << "\t\tstd::cout << x << \" * \" << y << \" = \" << x * y << std::endl;\n";

            toProgram << "\t}\n";
        }
    }



    toProgram << "\treturn 0;\n}";

    toProgram.close();
    return 0;
}
