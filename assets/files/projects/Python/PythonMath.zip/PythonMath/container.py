#   This script is still a work in progres and thus lightly tested. Attempt use at
#   your own risk.

#   This class will keep track of all lists as separate DataSet
#   objects. It will also keep track of a history of commands
#   performed globally.
class DataSetContainer:
    def __init__(self):
        pass

#   This class will keep track of one list and its immediate
#   statistics as well as any operations performed on it.
class DataSet:
    def __init__(self):
        pass

#   This class will store all statistics for a data set.
#   Statistics include but are not limited to:
#   [ average, sum, size, mode, median, quartiles, range, standard deviation]
class Measures:
    def __init__(self):
        pass

#    Potential addition. Currently in debate.
class CommandInterpreter:
    def __init__():
        pass
