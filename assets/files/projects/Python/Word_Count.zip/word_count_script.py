#!/usr/bin/python3
import sys

# Constant tuple holding all special characters that need to be sanitized out of
# a word
SPECIAL_CHARS = ('!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '[', ']',
        '{', '}', ',', ';', ':', '/', '\\', '?', '<', '>', '+', '-', '=', '~', '.')

MIN_COUNT = 5
# @Brief
#       Takes a dictionary of words to numbers and finds the most used words
#       in that dictionary.
def most_used_words(word_count):
    word_list = []
    current_max = MIN_COUNT

    for word in word_count:
        if(current_max == word_count[word]):
            word_list.append(word)
        elif(current_max < word_count[word]):
            word_list = []
            word_list.append(word)
            current_max = word_count[word]

    return word_list

# @Brief
#       Takes a string which is checked for any special characters
#       (!, @, #, $, %, ^, &, *, (,), [,], {,} ',', ;, :, /, \, ?, <, >, +, -, =, ~)
#       Those characters are removed and the cleaned string returned.
#       Only exception is the single quote. Contractions are counted as their own words
#       in this project.
# @Input
#       a string representing a potential word
# @Output
#       a string without any special characters
def sanitize(word):
    word = word.strip()
    word = word.lower()
    for char in SPECIAL_CHARS:
        word = word.replace(char, '')

    return word

# @Brief
#       Takes a file, opens it, and counts each word in it after they are sanitized.
# @Input
#       A filename
# @Output
#       Either a dictionary with the word count or an error if the file could not be opened.
def analyze(file):
    word_count = {}
    raw_input = open(file, 'r').read()
    raw_input = raw_input.split('\n')

    # Split up the text received in a list of words
    formatted_input = []
    for line in raw_input:
        for word in line.split(' '):
            if(word != ''):
                # sanitize the word before putting it in the list
                formatted_input.append(sanitize(word))

    # Count up the words in the dictionary
    for word in formatted_input:
        if(word not in word_count):
            word_count[word] = 1
        else:
            word_count[word] += 1

    return word_count

# @Brief
#       All files are looped through in this functions, the final answer is printed
#       to the screen, inside this function.
# @Input
#       The list of all files to be analyzed.
# @Output NONE
def check_files(files):
    main_dictionary = {}
    # Open each file separately
    for file in files:
        main_dictionary[file] = analyze(file)

    # Print for every file, every word and the number of times it was found.
    print('\n')
    for pair in main_dictionary:
        print(pair, ':')
        for word in main_dictionary[pair]:
            tabs = ''
            if(len(word) <= 3):
                tabs = '\t\t\t\t'
            elif (len(word) <= 11):
                tabs = '\t\t\t'
            elif(len(word) <= 19):
                tabs = '\t\t'
            else:
                tabs = '\t'
            print('\t',word, ':', tabs, main_dictionary[pair][word])

        print('\nThe most used word (or words if tied), given a count >', MIN_COUNT, ': ')
        for word in most_used_words(main_dictionary[pair]):
            print(word, 'with a count of', main_dictionary[pair][word])

        print('\n')

# Direct execution checker
if(__name__ == "__main__"):
    if(len(sys.argv) == 1):
        print('No files given. Nothing to do. Exiting.')
        exit(1)

    arguments = []
    for i in range(1, len(sys.argv)):
        arguments.append(sys.argv[i])
    check_files(arguments)
