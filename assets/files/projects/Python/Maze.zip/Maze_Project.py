#       Creator of this file is Mircea Dumitrache (CWID:890-713-464)
#       Contact: dmircea@csu.fullerton.edu
#       This file will ask the user for a width and height then create a
#       maze with the given parameters.

import random
import time

#   Cell class that implements the sections of the maze
class Cell:
    def __init__(self,region):
        self.north = False  #False if there is a wall, true otherwise
        self.west = False   #Sama as above
        self.region = region   #Region of the cell, begins as a unique number
        self.connected = [self] #A list of cells in the same region as this one

    def __str__(self):      #       NEVER USED          
        return self.region

#   Kruskal's Algorithm
def kruskalAlg(matrix):
    random.seed()   #intialize the genereator

    #Variable used below
    randNumY = 0
    randNumX = 0
    randGate = ""

    #       While loop: persistently checks if the region of the starting position
    #       and region of the ending position are the same
    #       If they are identical stop the loop, else continue
    #       NOTE: The algorithm gives priority to lower regions, at end of algorithm the region of Start and Finish will be 0.
    while(matrix[0][0].region != matrix[len(matrix)-1][len(matrix[0])-1].region):
        #       Gives randNumX a random value from 0 to length of the matrix outer list
        randNumX = random.randrange(len(matrix))
        
        #       Gives randNumY a random value from 0 to length of the matrix inner list
        #       All inner lists will have the same length.
        randNumY = random.randrange(len(matrix[0]))
        
        #       Chooses a random gate
        randGate = random.choice(["N","W"])
        
        #print(randNumX)     #   DEBUG
        #print(randNumY)     #   DEBUG
        #print(randGate)        #   DEBUG

        #       If statement: first check if the gate chosen is North
        #       Second check if the cell is a top cell(has no cells above it) if so the North gate should remain closed
        #       Third check if the region of the current cell and the upper cell are not the same
        if (randGate == "N" and randNumX -1 >= 0 and matrix[randNumX-1][randNumY].region != matrix[randNumX][randNumY].region):
            #print("X:" + str(randNumX) + ",Y:" + str(randNumY))        #DEBUG

            #       Open the North gate
            matrix[randNumX][randNumY].north = True

            #       Create newRegion with the upper cells region
            newRegion = matrix[randNumX-1][randNumY].region

            #       Create a list and copy the cells in "connected" of the upper cell to it
            newListConnect = matrix[randNumX-1][randNumY].connected[:]

            #       Extend the list with the contents of "connected" from the current cell
            newListConnect.extend(matrix[randNumX][randNumY].connected)
            
            #print("newListConnect: ", end="")      #DEBUG
            #print(newListConnect)                  #DEBUG
            #print("newRegion: ", end="")           #DEBUG
            #print(newRegion)                       #DEBUG

            #       Loop through the newListConnect and for each cell change the region to newRegion and connected to newListConnect
            #       Update loop
            for cell in newListConnect:
                cell.region = newRegion
                cell.connected = newListConnect[:]


        #       If statemtent: first check if the gate chosen is West
        #       Second check if the cell is a far right cell (near the western wall) if so the West gate should remain close
        #       Third check if the region in the current cell and the cell to its right are no the same
        if(randGate == "W" and randNumY < len(matrix[0])-1 and matrix[randNumX][randNumY].region != matrix[randNumX][randNumY+1].region):
            #print("X:" + str(randNumX) + ",Y:" + str(randNumY))        #DEBUG

            #       Open the West gate
            matrix[randNumX][randNumY].west = True

            #       Create newRegion with the current cells regions
            newRegion = matrix[randNumX][randNumY].region

            #       Create a list and copy the cells in "connected" of the current cells to it
            newListConnect = matrix[randNumX][randNumY].connected[:]

            #       Extend the list with the contents of "connected" from the cell to the right
            newListConnect.extend(matrix[randNumX][randNumY+1].connected)
            
            #print("newListConnect: ", end="")      #DEBUG
            #print(newListConnect)                  #DEBUG
            #print("newRegion: ", end="")           #DEBUG
            #print(newRegion)                       #DEBUG

            #       Loop through the newListConnect and do the same as in the previous if statement
            for cell in newListConnect:
                cell.region = newRegion
                cell.connected = newListConnect[:]

        #print_maze(matrix)     #DEBUG
        #input()                #DEBUG
                

#       Here is the print function
#       This function utilizes the west and north gates to print out an accurate representation of the maze
#       Make certain that the font used in python gives equal length to each character( Reccommended to use MS Gothic.)
def print_maze(maze):
    print("Begin printing maze!")

    #       This loops through all objects of the outer list
    for i in range(len(maze)):

        #       Loops through all objects of an inner list
        #       Loop for creation of the Northern walls and corners
        for north in range(len(maze[i])):
            print("+",end ="")
            if(maze[i][north].north):
                print(" ", end="")  #this is temporary
            else:
                print("-", end="")

        #       Prints the last corner
        print("+")
        #       Prints the First vertical wall
        print("|", end = "")


        #       Loops through all objects of an inner list
        #       Loop for creation of the Vertical walls and spaces
        for west in range(len(maze[i])):
            if(i == 0 and west == 0):
                print("S", end = "")
            elif(i == len(maze)-1 and west == len(maze[i])-1):
                print("F", end = "")
            else:
                print(" ", end = "")
            if (maze[i][west].west):
                print(" ", end="")
            else:
                print("|", end="")

        #       Prints nothing but allows new line
        print("")

    #       Prints the very last wall
    for i in range(len(maze[0])):
        print("+",end="")
        print("-",end="")

    #       Prints the very last corner
    print("+")
            
            
#       Here is the main loop which will keep asking for values to make mazes
while(True):

    #       Ask for input
    width = int(input("Please type the width: "))
    height = int(input("Please type the height: "))
    
    #       Break out of the loop if either width or height is 0 or less
    #       This will close the program
    if(width <=0 or height <=0):
        break

    #       Create a list in which to crate the maze
    graph = []

    #       Append a list to the graph list in order to make a 2D list
    for i in range(height):
        graph.append([])

    temp = 0
    #       Add a Cell with a unique region so that a 2D list of cells is made
    #       where height is height and width is width
    for i in range(height):
        for ii in range(width):
            graph[i].append(Cell(temp))     #Append a cell to inner lists
            temp += 1                       #Iterate the counter for regions


    #       Prints the first untouched maze
    print_maze(graph)

    input("Press Enter to continue.")

    #       Use Kruskal's Algorithm on the graph
    kruskalAlg(graph)

    #       Print the touched maze
    print_maze(graph)
