Project name: Maze Project (file name is: "Maze_Project.py" without quotes)

Instructions: Use Python to run the script (This program was created and tested with Python (3.6.1))
		1. Open the "Maze_Project.py" file using Python IDLE
		2. Click on "Run" on the task bare at the top of the window
		3. Select "Run Module"

If using Linux: 
		1. Open a new terminal window, if one is not already open.
			1a. Make sure that python is installed and uses version 3.6.1 or greater.
			    Use the command "which python3" to verify that python3 is installed.
			    Use the command "python3 --version" to verify the version of python.
		2. Navigate to the folder where the script was sotred.
		3. Run the command "python3 Maze_Project.py" to start the program.

Setup and Installation: Install Python 3.6.1 or above, then follow instructions.

How to use:
	The program will ask the user of the width and height of the maze that is to be created.
	A maze with all doors closed will be printed to the screen to show the size of the maze.
	Note: (If the maze appears strange, change the font to MS Gothic by Clicking on Options and then
	on Configure IDLE in the IDLE window.)
	Press enter to use Kruskal's Algorithm to make the maze.
	The actual maze will be printed to the sceen.
	You may keep creating mazes until you place a 0 or less in either the width or height variables.
